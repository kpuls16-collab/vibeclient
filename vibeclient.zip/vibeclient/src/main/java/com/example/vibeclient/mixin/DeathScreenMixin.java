package com.example.vibeclient.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(DeathScreen.class)
public class DeathScreenMixin {
    private static boolean deathChatEnabled = false;

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void vibeclient$keyPressed(KeyEvent event, CallbackInfoReturnable<Boolean> cir) {
        Minecraft mc = Minecraft.getInstance();

        // Left Ctrl toggles the feature
        if (event.key() == GLFW.GLFW_KEY_LEFT_CONTROL) {
            deathChatEnabled = !deathChatEnabled;
            mc.gui.setOverlayMessage(
                Component.literal("Death chat: " + (deathChatEnabled ? "ON" : "OFF")), false);
            cir.setReturnValue(true);
            return;
        }

        if (!deathChatEnabled) return;

        // Follows your Open Chat / Open Command keybinds
        if (mc.options.keyChat.matches(event)) {
            mc.setScreen(new ChatScreen("", false));
            cir.setReturnValue(true);
        } else if (mc.options.keyCommand.matches(event)) {
            mc.setScreen(new ChatScreen("/", false));
            cir.setReturnValue(true);
        }
    }
}
