package com.vibeclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

/** Servers where you've chosen to allow Vibe Client's modules. Saved in the config folder. */
public final class ServerAllowList {
    private static final Set<String> HOSTS = new TreeSet<>();
    private static boolean loaded;

    private ServerAllowList() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("vibeclient-allowed-servers.txt");
    }

    /** Lowercase, drop a trailing :port. */
    public static String normalize(String address) {
        if (address == null) return "";
        String a = address.trim().toLowerCase(Locale.ROOT);
        int i = a.lastIndexOf(':');
        if (i > 0 && a.substring(i + 1).chars().allMatch(Character::isDigit)) a = a.substring(0, i);
        return a;
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            if (Files.exists(file())) {
                for (String line : Files.readAllLines(file())) {
                    String h = normalize(line);
                    if (!h.isEmpty()) HOSTS.add(h);
                }
            }
        } catch (IOException ignored) {}
    }

    private static void save() {
        try {
            Files.write(file(), HOSTS);
        } catch (IOException ignored) {}
    }

    public static boolean isAllowed(String address) {
        load();
        return HOSTS.contains(normalize(address));
    }

    public static boolean add(String address) {
        load();
        boolean changed = HOSTS.add(normalize(address));
        if (changed) save();
        return changed;
    }

    public static boolean remove(String address) {
        load();
        boolean changed = HOSTS.remove(normalize(address));
        if (changed) save();
        return changed;
    }

    public static Set<String> all() {
        load();
        return Set.copyOf(HOSTS);
    }
}
