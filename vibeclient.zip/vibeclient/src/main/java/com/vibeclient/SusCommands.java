package com.vibeclient;

import com.vibeclient.module.SusChunksModule;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Chat commands (never sent to the server):
 *   #sus         list the top 5 chunks by base %
 *   #sus_clear   forget everything found so far
 */
public final class SusCommands {
    private SusCommands() {}

    public static boolean handle(String message) {
        String msg = message.trim().toLowerCase(Locale.ROOT);
        if (!msg.equals("#sus") && !msg.equals("#sus_clear")) return false;

        SusChunksModule sus = VibeClient.MODULES.get(SusChunksModule.class);
        if (msg.equals("#sus_clear")) {
            sus.clear();
            say("Sus Chunks cleared.");
            return true;
        }

        if (!sus.isEnabled()) { say("Sus Chunks is off. Turn it on in the menu (Right Shift)."); return true; }

        List<SusChunksModule.Info> top = sus.getInfos().values().stream()
                .filter(i -> sus.isSus(i) || sus.basePercent(i) >= sus.minBasePercent)
                .sorted(Comparator.comparingInt((SusChunksModule.Info i) -> sus.basePercent(i)).reversed()
                        .thenComparing(Comparator.comparingDouble(SusChunksModule.Info::activity).reversed()))
                .limit(5)
                .toList();

        if (top.isEmpty()) { say("Nothing found yet. Move around so chunks load."); return true; }
        say("Top chunks:");
        for (var i : top) {
            say("  (" + (i.cx() * 16 + 8) + ", " + i.y() + ", " + (i.cz() * 16 + 8) + ")  "
                    + sus.basePercent(i) + "% base" + (sus.isSus(i) ? "  SUS" : ""));
        }
        return true;
    }

    private static void say(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[Vibe] " + text));
    }
}
