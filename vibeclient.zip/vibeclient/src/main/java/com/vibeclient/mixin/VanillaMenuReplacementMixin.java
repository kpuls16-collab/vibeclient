package com.vibeclient.mixin;

import com.vibeclient.gui.VibeMainMenuScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replaces the vanilla startup title screen with the supplied Vibe Client home screen. */
@Mixin(Minecraft.class)
public abstract class VanillaMenuReplacementMixin {
    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void vibeclient$replaceTitleScreen(Screen screen, CallbackInfo ci) {
        if (screen instanceof TitleScreen) {
            ((Minecraft)(Object)this).setScreen(new VibeMainMenuScreen());
            ci.cancel();
        }
    }
}
