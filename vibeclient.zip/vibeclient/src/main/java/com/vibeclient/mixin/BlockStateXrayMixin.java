package com.vibeclient.mixin;

import com.vibeclient.module.XrayModule;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * X-Ray hooks on every block state. While X-Ray is on, "natural" blocks:
 *  - are not drawn at all (render shape becomes INVISIBLE),
 *  - no longer hide the faces of blocks next to them (so buried ores get their sides drawn),
 *  - no longer count as solid for the cave-culling graph (so nothing behind them is skipped).
 * Only the rendering side is touched; the server thread is never affected.
 * Each hook uses require = 0, so one that doesn't match 26.1 is skipped instead of crashing.
 */
@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockStateXrayMixin {
    @Shadow
    public abstract Block getBlock();

    @Inject(method = "getRenderShape", at = @At("RETURN"), cancellable = true, require = 0)
    private void vibeclient$renderShape(CallbackInfoReturnable<RenderShape> cir) {
        if (XrayModule.shouldHide(getBlock())) cir.setReturnValue(RenderShape.INVISIBLE);
    }

    @Inject(method = "canOcclude", at = @At("RETURN"), cancellable = true, require = 0)
    private void vibeclient$canOcclude(CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue() && XrayModule.shouldHide(getBlock())) cir.setReturnValue(false);
    }

    @Inject(method = "isSolidRender()Z", at = @At("RETURN"), cancellable = true, require = 0)
    private void vibeclient$solidRender(CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue() && XrayModule.shouldHide(getBlock())) cir.setReturnValue(false);
    }
}
