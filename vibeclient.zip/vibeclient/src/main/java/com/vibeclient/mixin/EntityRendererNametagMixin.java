package com.vibeclient.mixin;

import com.vibeclient.module.NametagsModule;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hides the vanilla floating name over players while Nametags is on, so the name isn't
 * shown twice. If the method signature differs in 26.1 this quietly does nothing and you
 * just see both tags (turn off "Hide vanilla tags" or ignore it).
 */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererNametagMixin {
    @Inject(method = "shouldShowName", at = @At("HEAD"), cancellable = true, require = 0)
    private void vibeclient$hideVanillaName(Entity entity, double distanceToCameraSq, CallbackInfoReturnable<Boolean> cir) {
        if (NametagsModule.hideVanillaActive && entity instanceof Player) {
            cir.setReturnValue(false);
        }
    }
}
