package com.vibeclient;

import com.vibeclient.module.HealthIndicatorModule;
import com.vibeclient.module.NametagsModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws the name tags on the HUD layer. World positions are projected to the screen with a
 * small piece of camera math, so no world-space text rendering is needed.
 * Limitation: the maths follows the camera entity's eye (first person / Freecam); in third
 * person the tags sit slightly off.
 */
public final class NametagsRenderer {
    private NametagsRenderer() {}

    private static final int CELL_W = 22;

    public static void render(GuiGraphicsExtractor g, float partial) {
        NametagsModule nt = VibeClient.MODULES.get(NametagsModule.class);
        if (!nt.isEnabled()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Entity cam = mc.getCameraEntity();
        if (cam == null) return;

        // Camera basis vectors
        Vec3 eye = cam.getEyePosition(partial);
        double yaw = Math.toRadians(cam.getViewYRot(partial));
        double pitch = Math.toRadians(cam.getViewXRot(partial));
        Vec3 f = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 r = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 u = r.cross(f);

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) sw / sh;
        double maxDistSq = (double) nt.maxDistance * nt.maxDistance;
        int lift = VibeClient.MODULES.get(HealthIndicatorModule.class).isEnabled() ? 24 : 0;

        for (Player pl : mc.level.players()) {
            if (pl == cam || !pl.isAlive()) continue;

            Vec3 head = pl.getPosition(partial).add(0, pl.getBbHeight() + 0.45, 0);
            Vec3 d = head.subtract(eye);
            if (d.lengthSqr() > maxDistSq) continue;
            double z = d.dot(f);
            if (z < 0.1) continue;
            double sx = sw / 2.0 + (d.dot(r) / z) / (tanHalf * aspect) * (sw / 2.0);
            double sy = sh / 2.0 - (d.dot(u) / z) / tanHalf * (sh / 2.0);
            if (sx < -200 || sx > sw + 200 || sy < -100 || sy > sh + 100) continue;

            drawTag(g, mc, nt, pl, (int) Math.round(sx), (int) Math.round(sy) - lift);
        }
    }

    private static void drawTag(GuiGraphicsExtractor g, Minecraft mc, NametagsModule nt, Player pl, int cx, int bottomY) {
        // ---- name ----
        String name = pl.getName().getString();
        int nameW = mc.font.width(name);
        int nameY = bottomY - 11;
        g.fill(cx - nameW / 2 - 3, nameY - 2, cx + nameW / 2 + 3, nameY + 10, 0x90000000);
        g.text(mc.font, name, cx - nameW / 2, nameY, 0xFFFFFFFF, true);

        // ---- items ----
        List<ItemStack> items = new ArrayList<>();
        if (nt.showHands) add(items, pl.getMainHandItem());
        if (nt.showArmor) {
            add(items, pl.getItemBySlot(EquipmentSlot.HEAD));
            add(items, pl.getItemBySlot(EquipmentSlot.CHEST));
            add(items, pl.getItemBySlot(EquipmentSlot.LEGS));
            add(items, pl.getItemBySlot(EquipmentSlot.FEET));
        }
        if (nt.showHands) add(items, pl.getOffhandItem());
        if (items.isEmpty()) return;

        int rowW = items.size() * CELL_W;
        int rowTop = nameY - 4 - 27;
        int x0 = cx - rowW / 2;
        g.fill(x0 - 2, rowTop - 2, x0 + rowW + 2, rowTop + 27 + 1, 0x60000000);

        for (int i = 0; i < items.size(); i++) {
            ItemStack s = items.get(i);
            int ix = x0 + i * CELL_W + (CELL_W - 16) / 2;
            g.item(s, ix, rowTop);   // if this fails to compile, the item-drawing method was renamed

            if (s.isDamageableItem()) {
                int max = s.getMaxDamage();
                int pct = Math.max(0, Math.round((max - s.getDamageValue()) * 100f / max));
                int color = pct > 60 ? 0xFF55FF55 : pct > 30 ? 0xFFFFFF55 : 0xFFFF5555;
                String t = Integer.toString(pct);
                g.text(mc.font, t, x0 + i * CELL_W + (CELL_W - mc.font.width(t)) / 2, rowTop + 17, color, true);
            } else if (s.getCount() > 1) {
                String t = Integer.toString(s.getCount());
                g.text(mc.font, t, ix + 17 - mc.font.width(t), rowTop + 9, 0xFFFFFFFF, true);
            }
        }
    }

    private static void add(List<ItemStack> list, ItemStack s) {
        if (!s.isEmpty()) list.add(s);
    }
}
