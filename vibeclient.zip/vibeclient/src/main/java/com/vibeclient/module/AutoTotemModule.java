package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Items;

/**
 * Detects the offhand totem leaving the offhand (a pop), opens the inventory,
 * swaps a spare totem into the offhand, then closes the inventory.
 */
public class AutoTotemModule extends Module {
    private enum State { IDLE, SWAP, CLOSE }

    // Settings
    public boolean openInventory = true; // show the inventory screen while swapping
    public int delayTicks = 2;           // ticks to wait before the swap

    private State state = State.IDLE;
    private int timer;
    private boolean hadTotem;
    private boolean openedByUs;

    public AutoTotemModule() {
        super("Auto Totem", "Combat");
    }

    @Override
    protected void onDisable() { reset(); }

    private void reset() {
        state = State.IDLE;
        timer = 0;
        hadTotem = false;
        openedByUs = false;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) { reset(); return; }

        boolean hasTotem = p.getOffhandItem().is(Items.TOTEM_OF_UNDYING);

        switch (state) {
            case IDLE -> {
                // Pop = totem was in offhand last tick and now it is gone.
                if (hadTotem && !hasTotem && findSpareTotem(p) != -1) {
                    if (openInventory && mc.screen == null) {
                        mc.setScreen(new InventoryScreen(p));
                        openedByUs = true;
                    }
                    timer = delayTicks;
                    state = State.SWAP;
                }
                hadTotem = hasTotem;
            }
            case SWAP -> {
                if (timer-- > 0) return;
                int slot = findSpareTotem(p);
                if (slot != -1) swapWithOffhand(mc, p, slot);
                timer = 1;
                state = State.CLOSE;
            }
            case CLOSE -> {
                if (timer-- > 0) return;
                if (openedByUs) mc.setScreen(null);
                openedByUs = false;
                hadTotem = p.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
                state = State.IDLE;
            }
        }
    }

    /** Returns an inventory index (0-35: hotbar 0-8, main 9-35) holding a totem, or -1. */
    private int findSpareTotem(LocalPlayer p) {
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }

    /**
     * Inventory menu slots: 9-35 main, 36-44 hotbar. SWAP with button 40 = offhand.
     * If the compiler complains about this call, the method/enum was renamed in
     * 26.1 - this is the only place that needs fixing.
     */
    private void swapWithOffhand(Minecraft mc, LocalPlayer p, int invIndex) {
        int menuSlot = invIndex < 9 ? invIndex + 36 : invIndex;
        mc.gameMode.handleContainerInput(
                p.inventoryMenu.containerId, menuSlot, 40, ContainerInput.SWAP, p);
    }
}
