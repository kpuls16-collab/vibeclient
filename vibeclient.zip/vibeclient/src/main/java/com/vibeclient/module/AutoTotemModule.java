package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Items;

/**
 * Keeps a totem in your offhand.
 *
 * Every tick: if your offhand is empty and you have a spare totem, it swaps one in, in the same
 * tick it notices. It doesn't wait for a "pop" event and it doesn't depend on any earlier state,
 * so it also covers joining a server, respawning, changing dimension, and a failed swap (it just
 * tries again once the server has re-synced your inventory).
 *
 * The swap is a normal inventory click (the same as pressing F over the slot). It works with the
 * inventory closed and also while another container (chest, crafting table...) is open.
 */
public class AutoTotemModule extends Module {
    // Settings
    public boolean openInventory = false;  // briefly show the inventory screen (cosmetic; it interrupts movement)
    public int delayTicks = 0;             // extra wait before swapping (0 = instant)
    public boolean keepHotbar = true;      // take totems from the inventory first, hotbar last

    private int waitTicks;
    private boolean noticed;
    private int closeIn;
    private boolean openedByUs;

    public AutoTotemModule() {
        super("Auto Totem", "Combat");
        settings.add(Setting.ofBool("Keep hotbar totems", () -> keepHotbar, v -> keepHotbar = v));
        settings.add(Setting.ofInt("Extra delay (ticks)", () -> delayTicks, v -> delayTicks = v, 0, 10, 1));
        settings.add(Setting.ofBool("Show inventory briefly", () -> openInventory, v -> openInventory = v));
    }

    @Override
    protected void onDisable() {
        waitTicks = 0;
        noticed = false;
        closeIn = 0;
        openedByUs = false;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;

        if (closeIn > 0 && --closeIn == 0 && openedByUs) {
            if (mc.screen instanceof InventoryScreen) mc.setScreen(null);
            openedByUs = false;
        }

        if (!p.getOffhandItem().isEmpty()) { noticed = false; waitTicks = 0; return; }
        if (p.isDeadOrDying()) return;

        if (waitTicks > 0) { waitTicks--; return; }
        if (!noticed) {
            noticed = true;
            if (delayTicks > 0) { waitTicks = delayTicks; return; }
        }

        int spare = findSpareTotem(p);
        if (spare == -1) return;

        if (swapToOffhand(mc, p, spare)) {
            waitTicks = 2; // give the server a moment before we'd ever retry
            if (openInventory && mc.screen == null) {
                mc.setScreen(new InventoryScreen(p));
                openedByUs = true;
                closeIn = 4;
            }
        }
    }

    /**
     * Returns an inventory index (0-35: hotbar 0-8, main 9-35) holding a totem, or -1.
     * With "Keep hotbar totems" on, the main inventory is searched first and the hotbar only
     * when nothing is left there.
     */
    private int findSpareTotem(LocalPlayer p) {
        int first = keepHotbar ? 9 : 0;
        for (int n = 0; n < 36; n++) {
            int i = (first + n) % 36;
            if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }

    /**
     * Swaps the given inventory slot with the offhand (click button 40). Uses whichever menu is
     * open right now, looking up where your inventory slot sits in that menu.
     */
    private boolean swapToOffhand(Minecraft mc, LocalPlayer p, int invIndex) {
        AbstractContainerMenu menu = p.containerMenu;
        for (Slot s : menu.slots) {
            if (s.container == p.getInventory() && s.getContainerSlot() == invIndex) {
                // If the compiler complains about this call, the click method was renamed in 26.1.
                mc.gameMode.handleContainerInput(menu.containerId, s.index, 40, ContainerInput.SWAP, p);
                return true;
            }
        }
        return false;
    }
}
