package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/**
 * While switched on and holding bottles o' enchanting (main hand or offhand), throws them
 * automatically at a speed of "one full stack (64) per N seconds". Default N = 6.
 */
public class FastXpModule extends Module {
    private static final int STACK = 64;

    // Settings
    public double stackSeconds = 6.0;  // seconds to throw a full stack of 64
    public int maxPerTick = 4;         // upper limit when the stack time is very short

    private double carry;

    public FastXpModule() {
        super("Fast XP", "Utility");
        settings.add(Setting.ofDouble("Stack time (sec)", () -> stackSeconds, v -> stackSeconds = v, 0.5, 30.0, 0.5));
        settings.add(Setting.ofInt("Max throws / tick", () -> maxPerTick, v -> maxPerTick = v, 1, 8, 1));
    }

    @Override
    protected void onDisable() { carry = 0; }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) { carry = 0; return; }

        InteractionHand hand;
        if (p.getMainHandItem().is(Items.EXPERIENCE_BOTTLE)) hand = InteractionHand.MAIN_HAND;
        else if (p.getOffhandItem().is(Items.EXPERIENCE_BOTTLE)) hand = InteractionHand.OFF_HAND;
        else { carry = 0; return; }

        // Throws earned this tick: 64 bottles spread evenly over stackSeconds.
        carry += STACK / (Math.max(0.5, stackSeconds) * 20.0);
        int throwsNow = Math.min((int) carry, maxPerTick);
        carry -= throwsNow;
        if (carry > 1) carry = 1; // don't build up a backlog if we're capped

        for (int i = 0; i < throwsNow; i++) {
            if (!p.getItemInHand(hand).is(Items.EXPERIENCE_BOTTLE)) break;
            mc.gameMode.useItem(p, hand);
            p.swing(hand);
        }
    }
}
