package com.vibeclient.module;

import net.minecraft.client.Minecraft;

public abstract class Module {
    private final String name;
    private final String category;
    private boolean enabled;

    protected Module(String name, String category) {
        this.name = name;
        this.category = category;
    }

    public String getName() { return name; }
    public String getCategory() { return category; }
    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    /** Runs at the START of the client tick, before vanilla handles clicks. */
    public void onStartTick(Minecraft mc) {}
    public void onTick(Minecraft mc) {}
}
