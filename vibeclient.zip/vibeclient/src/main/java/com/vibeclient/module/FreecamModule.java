package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Detaches the camera from your body. A client-only camera entity flies around while your
 * real player stays where it is (its input is muted, its rotation is held, and clicks are
 * blocked so nothing gets sent from the camera's position). Turning it off puts the view
 * back on your body.
 *
 * Fly with the normal movement keys: forward/back/left/right, jump = up, sneak = down,
 * sprint = faster.
 */
public class FreecamModule extends Module {
    // Settings
    public double speed = 0.8;            // blocks per tick
    public double sprintMultiplier = 2.5;

    private RemotePlayer cam;
    private ClientLevel level;
    private ClientInput origInput;
    private float origYaw, origPitch;     // your body's rotation, held fixed
    private float camYaw, camPitch;

    public FreecamModule() {
        super("Freecam", "Visuals");
    }

    @Override
    protected void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { setEnabled(false); return; }

        level = mc.level;
        origYaw = p.getYRot();
        origPitch = p.getXRot();
        camYaw = origYaw;
        camPitch = origPitch;

        cam = new RemotePlayer(mc.level, p.getGameProfile());
        cam.copyPosition(p);
        cam.setYRot(camYaw);
        cam.setXRot(camPitch);
        cam.setOldPosAndRot();

        // Mute the real player's movement input while we fly the camera.
        origInput = p.input;
        p.input = new ClientInput() {};

        mc.setCameraEntity(cam);
        p.displayClientMessage(Component.literal("Freecam ON"), true);
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p != null) {
            if (origInput != null) p.input = origInput;
            p.setYRot(origYaw);
            p.setXRot(origPitch);
            mc.setCameraEntity(p);
            p.displayClientMessage(Component.literal("Freecam OFF"), true);
        }
        cam = null;
        level = null;
        origInput = null;
    }

    /** Mouse look turns the real player; move that turn onto the camera and put the body back. */
    private void syncRotation(LocalPlayer p) {
        float dy = p.getYRot() - origYaw;
        float dp = p.getXRot() - origPitch;
        if (dy == 0 && dp == 0) return;

        camYaw += dy;
        camPitch = Mth.clamp(camPitch + dp, -90f, 90f);

        p.setYRot(origYaw);
        p.setXRot(origPitch);
        p.yRotO = origYaw;
        p.xRotO = origPitch;

        cam.setYRot(camYaw);
        cam.setXRot(camPitch);
        cam.setOldRot();
    }

    /** Called every rendered frame so looking around stays smooth. */
    public void frameUpdate() {
        Minecraft mc = Minecraft.getInstance();
        if (cam == null || mc.player == null) return;
        syncRotation(mc.player);
    }

    @Override
    public void onStartTick(Minecraft mc) {
        if (cam == null) return;
        LocalPlayer p = mc.player;
        if (p == null || mc.level != level || p.isDeadOrDying()) { setEnabled(false); return; }

        syncRotation(p);

        // Nothing may be attacked / used / broken from the camera's position.
        while (mc.options.keyAttack.consumeClick()) {}
        while (mc.options.keyUse.consumeClick()) {}
        while (mc.options.keyPickItem.consumeClick()) {}
        mc.options.keyAttack.setDown(false);
        mc.options.keyUse.setDown(false);

        if (mc.screen != null) return; // no flying while a menu is open

        double forward = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
        double strafe = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
        double vertical = (mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0);

        cam.setOldPosAndRot();
        double yawRad = Math.toRadians(camYaw);
        Vec3 right = new Vec3(-Math.cos(yawRad), 0, -Math.sin(yawRad));
        Vec3 move = cam.getLookAngle().scale(forward).add(right.scale(strafe)).add(0, vertical, 0);
        if (move.lengthSqr() > 0) {
            double s = speed * (mc.options.keySprint.isDown() ? sprintMultiplier : 1.0);
            move = move.normalize().scale(s);
            cam.setPos(cam.getX() + move.x, cam.getY() + move.y, cam.getZ() + move.z);
        }
    }
}
