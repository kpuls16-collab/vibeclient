package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.ConcurrentHashMap;

/**
 * X-Ray: only the blocks you pick stay visible; everything else becomes transparent.
 * Pick blocks with chat commands (see XrayCommands):  #xray <block>, #xray ores, #xray loot.
 * The hiding happens in BlockStateXrayMixin, which hooks the block render shape, so it also
 * works with Sodium. Water and lava are not hidden.
 */
public class XrayModule extends Module {
    /** Read by the mixin on the chunk-building threads. */
    public static volatile boolean renderActive;

    // Settings
    public boolean terrainTransparent = true;
    public boolean showOres = false;     // also keep every ore visible
    public boolean fullbright = true;
    public boolean oreGlow = false;      // optional outlines through walls
    public int radius = 24;
    public int scanInterval = 20;
    public int maxHits = 2000;

    /** Blocks that stay visible. */
    public final Set<Block> visible = ConcurrentHashMap.newKeySet();

    private static final ConcurrentHashMap<Block, Boolean> CACHE = new ConcurrentHashMap<>();
    private static volatile XrayModule current;

    private volatile List<EspModule.Hit> found = List.of();
    private int ticks;
    private boolean addedNightVision;

    public XrayModule() {
        super("X-Ray", "Visuals");
        current = this;
        settings.add(Setting.ofBool("See-through terrain", () -> terrainTransparent, v -> { terrainTransparent = v; refresh(); }));
        settings.add(Setting.ofBool("Show ores", () -> showOres, v -> { showOres = v; refresh(); }));
        settings.add(Setting.ofBool("Fullbright", () -> fullbright, v -> fullbright = v));
        settings.add(Setting.ofBool("Ore outlines", () -> oreGlow, v -> oreGlow = v));
        settings.add(Setting.ofInt("Outline radius", () -> radius, v -> radius = v, 8, 48, 4));
    }

    public List<EspModule.Hit> getFound() { return found; }

    // ------------------------------------------------------------------ block list

    public static boolean isOre(Block b) {
        String path = BuiltInRegistries.BLOCK.getKey(b).getPath();
        return path.endsWith("_ore") || path.equals("ancient_debris");
    }

    public static Block findBlock(String path) {
        for (Block b : BuiltInRegistries.BLOCK) {
            if (BuiltInRegistries.BLOCK.getKey(b).getPath().equals(path)) return b;
        }
        return null;
    }

    public static String nameOf(Block b) {
        return BuiltInRegistries.BLOCK.getKey(b).getPath();
    }

    /** Adds the usual loot blocks: chests, barrels, spawners, trial spawners, vaults. */
    public void addLoot() {
        visible.addAll(List.of(Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL,
                Blocks.SPAWNER, Blocks.TRIAL_SPAWNER, Blocks.VAULT));
    }

    public void clearVisible() {
        visible.clear();
        showOres = false;
    }

    public String serializeBlocks() {
        StringJoiner j = new StringJoiner(",");
        for (Block b : visible) j.add(nameOf(b));
        return j.toString();
    }

    public void loadBlocks(String csv) {
        visible.clear();
        for (String part : csv.split(",")) {
            String name = part.trim();
            if (name.isEmpty()) continue;
            Block b = findBlock(name);
            if (b != null) visible.add(b);
        }
    }

    // ------------------------------------------------------------------ hiding rules

    /** Used by the mixin. Never true on the integrated server thread, so gameplay is unaffected. */
    public static boolean shouldHide(Block b) {
        return renderActive
                && !Thread.currentThread().getName().startsWith("Server")
                && isHidden(b);
    }

    public static boolean isHidden(Block b) {
        return CACHE.computeIfAbsent(b, XrayModule::computeHidden);
    }

    private static boolean computeHidden(Block b) {
        XrayModule x = current;
        if (x == null) return false;
        if (x.visible.contains(b)) return false;
        if (x.showOres && isOre(b)) return false;
        return true;
    }

    private void updateActive() {
        renderActive = isEnabled() && terrainTransparent;
    }

    /** Call after the block list or a setting changes: resets the cache and re-meshes the world. */
    public void refresh() {
        CACHE.clear();
        updateActive();
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.level == null) return;
        try {
            mc.levelRenderer.allChanged();
        } catch (Throwable ignored) {}
    }

    // ------------------------------------------------------------------ module lifecycle

    @Override
    protected void onEnable() {
        refresh();
        ticks = scanInterval;
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.player != null && visible.isEmpty() && !showOres) {
            mc.player.sendOverlayMessage(Component.literal("X-Ray: nothing selected. Type #xray <block>"));
        }
    }

    @Override
    protected void onDisable() {
        refresh();
        found = List.of();
        removeNightVision();
    }

    private void removeNightVision() {
        Minecraft mc = Minecraft.getInstance();
        if (addedNightVision && mc != null && mc.player != null) {
            mc.player.removeEffect(MobEffects.NIGHT_VISION);
        }
        addedNightVision = false;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { found = List.of(); return; }

        // Fullbright: hidden blocks no longer light anything, and the ground blocks real light,
        // so visible blocks underground would be pitch black without this.
        if (fullbright && terrainTransparent) {
            if (!p.hasEffect(MobEffects.NIGHT_VISION)) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                addedNightVision = true;
            }
        } else if (addedNightVision) {
            removeNightVision();
        }

        if (!oreGlow) { found = List.of(); return; }
        if (++ticks < scanInterval) return;
        ticks = 0;

        BlockPos c = p.blockPosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        List<EspModule.Hit> out = new ArrayList<>();

        scan:
        for (int x = c.getX() - radius; x <= c.getX() + radius; x++) {
            for (int z = c.getZ() - radius; z <= c.getZ() + radius; z++) {
                for (int y = c.getY() - radius; y <= c.getY() + radius; y++) {
                    m.set(x, y, z);
                    Block b = mc.level.getBlockState(m).getBlock();
                    if (!isOre(b)) continue;
                    int rgb = java.awt.Color.HSBtoRGB((nameOf(b).hashCode() & 0xFFFF) / 65535f, 0.85f, 1f);
                    out.add(new EspModule.Hit(x, y, z, ((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f));
                    if (out.size() >= maxHits) break scan;
                }
            }
        }
        found = List.copyOf(out);
    }
}
