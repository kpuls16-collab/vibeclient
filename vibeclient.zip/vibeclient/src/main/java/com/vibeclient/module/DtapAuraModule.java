package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * When you left click a player:
 *  1. switches to your sword BEFORE vanilla processes the click, so the hit lands with the sword
 *  2. places obsidian on the ground next to them (or reuses obsidian already there)
 *  3. switches to crystals and spam places / breaks a crystal on that obsidian
 *  4. switches back to the slot you started on
 */
public class DtapAuraModule extends Module {
    private enum State { IDLE, OBSIDIAN, CRYSTAL }

    // Settings
    public double reach = 4.5;       // max placement / break reach
    public int crystalTicks = 12;    // how long to spam crystals per cycle
    public int cooldown = 6;         // ticks before another cycle can start

    private State state = State.IDLE;
    private int origSlot;
    private int cooldownTimer;
    private int ticksInState;
    private Player target;
    private BlockPos obsidianPos;

    public DtapAuraModule() {
        super("Dtap Aura", "Combat");
    }

    @Override
    protected void onDisable() { reset(null); }

    private void reset(LocalPlayer p) {
        if (p != null && state != State.IDLE) selectSlot(p, origSlot);
        state = State.IDLE;
        target = null;
        obsidianPos = null;
        ticksInState = 0;
    }

    // ---- Start of tick: runs before vanilla handles the click ----
    @Override
    public void onStartTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) return;
        if (state != State.IDLE || cooldownTimer > 0) return;
        if (!mc.options.keyAttack.isDown()) return;
        if (!(mc.hitResult instanceof EntityHitResult ehr) || !(ehr.getEntity() instanceof Player victim)) return;
        if (victim == p || !victim.isAlive()) return;

        int sword = findHotbarSword(p);
        if (sword == -1 || findHotbar(p, Items.OBSIDIAN) == -1 || findHotbar(p, Items.END_CRYSTAL) == -1) return;

        origSlot = p.getInventory().getSelectedSlot();
        target = victim;
        selectSlot(p, sword);       // vanilla's attack this tick now uses the sword
        state = State.OBSIDIAN;
        ticksInState = 0;
    }

    // ---- End of tick: the rest of the sequence ----
    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) { reset(null); return; }
        if (cooldownTimer > 0) cooldownTimer--;
        if (state == State.IDLE) return;

        if (target == null || !target.isAlive() || p.distanceTo(target) > 8) { finish(p); return; }

        switch (state) {
            case OBSIDIAN -> {
                if (ticksInState++ == 0) return; // give the sword hit a tick to go out

                BlockPos spot = chooseSpot(mc, p);
                if (spot == null) { finish(p); return; }
                obsidianPos = spot;

                if (!mc.level.getBlockState(spot).is(Blocks.OBSIDIAN)) {
                    selectSlot(p, findHotbar(p, Items.OBSIDIAN));
                    clickTop(mc, p, spot.below());
                }
                state = State.CRYSTAL;
                ticksInState = 0;
            }
            case CRYSTAL -> {
                if (ticksInState++ == 0) {
                    selectSlot(p, findHotbar(p, Items.END_CRYSTAL));
                    return; // let the slot change sync before acting
                }
                if (ticksInState > crystalTicks) { finish(p); return; }
                if (!mc.level.getBlockState(obsidianPos).is(Blocks.OBSIDIAN)) {
                    if (ticksInState > 6) finish(p); // obsidian never landed
                    return;
                }

                AABB zone = new AABB(obsidianPos.above()).inflate(0.5);
                var crystals = mc.level.getEntitiesOfClass(EndCrystal.class, zone, EndCrystal::isAlive);
                if (!crystals.isEmpty()) {
                    mc.gameMode.attack(p, crystals.get(0));      // spam break
                    p.swing(InteractionHand.MAIN_HAND);
                } else {
                    clickTop(mc, p, obsidianPos);                // spam place
                }
            }
            default -> {}
        }
    }

    private void finish(LocalPlayer p) {
        reset(p);
        cooldownTimer = cooldown;
    }

    /** Right-click the top face of `base`. */
    private void clickTop(Minecraft mc, LocalPlayer p, BlockPos base) {
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(base).add(0, 0.5, 0), Direction.UP, base, false);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, hit);
        p.swing(InteractionHand.MAIN_HAND);
    }

    /**
     * Picks the obsidian spot: a block next to the target's feet. Prefers existing obsidian
     * with room above; otherwise an empty, supported block within reach.
     */
    private BlockPos chooseSpot(Minecraft mc, LocalPlayer p) {
        BlockPos feet = target.blockPosition();
        Vec3 eye = p.getEyePosition();
        BlockPos bestExisting = null, bestNew = null;
        double dExisting = Double.MAX_VALUE, dNew = Double.MAX_VALUE;

        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos n = feet.relative(d);
            if (!mc.level.getBlockState(n.above()).isAir() || !mc.level.getBlockState(n.above(2)).isAir()) continue;
            double dist = eye.distanceToSqr(Vec3.atCenterOf(n).add(0, 0.5, 0));
            if (dist > reach * reach) continue;

            if (mc.level.getBlockState(n).is(Blocks.OBSIDIAN)) {
                if (dist < dExisting) { dExisting = dist; bestExisting = n; }
            } else if (mc.level.getBlockState(n).isAir() && !mc.level.getBlockState(n.below()).isAir()) {
                if (dist < dNew) { dNew = dist; bestNew = n; }
            }
        }
        return bestExisting != null ? bestExisting : bestNew;
    }

    private static int findHotbar(LocalPlayer p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(item)) return i;
        return -1;
    }

    private static int findHotbarSword(LocalPlayer p) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(ItemTags.SWORDS)) return i;
        return -1;
    }

    /** If this fails to compile, the selected-slot accessor was renamed in 26.1. */
    private static void selectSlot(LocalPlayer p, int slot) {
        if (slot >= 0) p.getInventory().setSelectedSlot(slot);
    }
}
