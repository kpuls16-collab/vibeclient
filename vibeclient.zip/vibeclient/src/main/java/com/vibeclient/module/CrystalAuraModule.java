package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.Comparator;

/**
 * While right click is held and you have an end crystal in hand:
 * places a crystal on the obsidian/bedrock you're aiming at, and breaks
 * nearby crystals, every N ticks.
 */
public class CrystalAuraModule extends Module {
    // Settings
    public int placeDelay = 0;       // ticks between placements (0 = every tick)
    public int breakDelay = 0;       // ticks between breaks (0 = every tick)
    public double breakRange = 4.5;  // max distance to a crystal to break it
    public boolean place = true;
    public boolean breakCrystals = true;

    private int placeTimer;
    private int breakTimer;

    public CrystalAuraModule() {
        super("Crystal Aura", "Combat");
        settings.add(Setting.ofBool("Place crystals", () -> place, v -> place = v));
        settings.add(Setting.ofBool("Break crystals", () -> breakCrystals, v -> breakCrystals = v));
        settings.add(Setting.ofInt("Place delay", () -> placeDelay, v -> placeDelay = v, 0, 10, 1));
        settings.add(Setting.ofInt("Break delay", () -> breakDelay, v -> breakDelay = v, 0, 10, 1));
        settings.add(Setting.ofDouble("Break range", () -> breakRange, v -> breakRange = v, 3.0, 6.0, 0.5));
    }

    @Override
    protected void onDisable() {
        placeTimer = 0;
        breakTimer = 0;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (!mc.options.keyUse.isDown()) return;

        InteractionHand hand = null;
        if (p.getMainHandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.MAIN_HAND;
        else if (p.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
        if (hand == null) return;

        if (placeTimer > 0) placeTimer--;
        if (breakTimer > 0) breakTimer--;

        if (breakCrystals && breakTimer <= 0 && tryBreak(mc, p)) {
            breakTimer = breakDelay;
        }
        if (place && placeTimer <= 0 && tryPlace(mc, p, hand)) {
            placeTimer = placeDelay;
        }
    }

    private boolean tryBreak(Minecraft mc, LocalPlayer p) {
        var eye = p.getEyePosition();
        EndCrystal target = mc.level
                .getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(breakRange + 1),
                        c -> c.isAlive() && c.getBoundingBox().distanceToSqr(eye) <= breakRange * breakRange)
                .stream()
                .min(Comparator.comparingDouble(c -> c.getBoundingBox().distanceToSqr(eye)))
                .orElse(null);
        if (target == null) return false;

        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
        return true;
    }

    private boolean tryPlace(Minecraft mc, LocalPlayer p, InteractionHand hand) {
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return false;

        BlockPos base = hit.getBlockPos();
        var state = mc.level.getBlockState(base);
        if (!state.is(Blocks.OBSIDIAN) && !state.is(Blocks.BEDROCK)) return false;

        BlockPos above = base.above();
        if (!mc.level.getBlockState(above).isAir() || !mc.level.getBlockState(above.above()).isAir()) return false;

        // Space must be free of entities (existing crystal, players, items...).
        AABB space = new AABB(above.getX(), above.getY(), above.getZ(),
                above.getX() + 1, above.getY() + 2, above.getZ() + 1);
        if (!mc.level.getEntities((net.minecraft.world.entity.Entity) null, space).isEmpty()) return false;

        mc.gameMode.useItemOn(p, hand, hit);
        p.swing(hand);
        return true;
    }
}
