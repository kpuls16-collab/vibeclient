package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * While right click is held and you have an end crystal in hand:
 * places a crystal on the obsidian/bedrock you're aiming at, and breaks nearby crystals.
 *
 * Built to keep up on servers with ping:
 *  - the break goes out first and the place right after it in the same tick, so we never wait
 *    for the server to tell us the old crystal is gone (the server handles them in order)
 *  - placing keeps working while your crosshair is on the crystal itself, by remembering the
 *    obsidian you were last aiming at
 *  - up to "Breaks per tick" crystals are hit each tick
 */
public class CrystalAuraModule extends Module {
    // Settings
    public int placeDelay = 0;       // ticks between placements (0 = every tick)
    public int breakDelay = 0;       // ticks between breaks (0 = every tick)
    public double breakRange = 4.0;  // servers ignore hits much past 4 blocks
    public int breaksPerTick = 3;
    public boolean place = true;
    public boolean breakCrystals = true;

    private static final double PLACE_REACH = 5.0;

    private int placeTimer;
    private int breakTimer;
    private BlockPos lastBase;       // last obsidian/bedrock you aimed at

    public CrystalAuraModule() {
        super("Crystal Aura", "Combat");
        settings.add(Setting.ofBool("Place crystals", () -> place, v -> place = v));
        settings.add(Setting.ofBool("Break crystals", () -> breakCrystals, v -> breakCrystals = v));
        settings.add(Setting.ofInt("Place delay", () -> placeDelay, v -> placeDelay = v, 0, 10, 1));
        settings.add(Setting.ofInt("Break delay", () -> breakDelay, v -> breakDelay = v, 0, 10, 1));
        settings.add(Setting.ofInt("Breaks per tick", () -> breaksPerTick, v -> breaksPerTick = v, 1, 4, 1));
        settings.add(Setting.ofDouble("Break range (blocks)", () -> breakRange, v -> breakRange = v, 3.0, 6.0, 0.5));
    }

    @Override
    protected void onDisable() {
        placeTimer = 0;
        breakTimer = 0;
        lastBase = null;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (!mc.options.keyUse.isDown()) { lastBase = null; return; }

        InteractionHand hand = null;
        if (p.getMainHandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.MAIN_HAND;
        else if (p.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
        if (hand == null) return;

        if (placeTimer > 0) placeTimer--;
        if (breakTimer > 0) breakTimer--;

        // Remember the obsidian you're aiming at, so placing keeps working once the crystal
        // is in the way of your crosshair.
        if (mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK && isBase(mc, hit.getBlockPos())) {
            lastBase = hit.getBlockPos();
        }

        // Break first, place second: the server processes them in this order.
        if (breakCrystals && breakTimer <= 0 && tryBreak(mc, p)) {
            breakTimer = breakDelay;
        }
        if (place && placeTimer <= 0 && tryPlace(mc, p, hand)) {
            placeTimer = placeDelay;
        }
    }

    private static boolean isBase(Minecraft mc, BlockPos pos) {
        var state = mc.level.getBlockState(pos);
        return state.is(Blocks.OBSIDIAN) || state.is(Blocks.BEDROCK);
    }

    private boolean tryBreak(Minecraft mc, LocalPlayer p) {
        Vec3 eye = p.getEyePosition();
        double r2 = breakRange * breakRange;
        List<EndCrystal> crystals = mc.level.getEntitiesOfClass(EndCrystal.class,
                p.getBoundingBox().inflate(breakRange + 1),
                c -> c.isAlive() && c.getBoundingBox().distanceToSqr(eye) <= r2);
        if (crystals.isEmpty()) return false;

        crystals.sort(Comparator.comparingDouble(c -> c.getBoundingBox().distanceToSqr(eye)));
        int n = Math.min(breaksPerTick, crystals.size());
        for (int i = 0; i < n; i++) mc.gameMode.attack(p, crystals.get(i));
        p.swing(InteractionHand.MAIN_HAND);
        return true;
    }

    private boolean tryPlace(Minecraft mc, LocalPlayer p, InteractionHand hand) {
        BlockHitResult hit = null;

        if (mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK && isBase(mc, bhr.getBlockPos())) {
            hit = bhr;
        } else if (mc.hitResult instanceof EntityHitResult && lastBase != null && isBase(mc, lastBase)
                && p.getEyePosition().distanceToSqr(Vec3.atCenterOf(lastBase)) <= PLACE_REACH * PLACE_REACH) {
            // Crosshair is on the crystal sitting on the obsidian: click the obsidian's top anyway.
            hit = new BlockHitResult(Vec3.atCenterOf(lastBase).add(0, 0.5, 0), Direction.UP, lastBase, false);
        }
        if (hit == null) return false;

        BlockPos above = hit.getBlockPos().above();
        if (!mc.level.getBlockState(above).isAir() || !mc.level.getBlockState(above.above()).isAir()) return false;

        // Space must be free of entities. Crystals don't count: we just sent the break for them.
        AABB space = new AABB(above.getX(), above.getY(), above.getZ(),
                above.getX() + 1, above.getY() + 2, above.getZ() + 1);
        if (!mc.level.getEntities((Entity) null, space, e -> !(e instanceof EndCrystal)).isEmpty()) return false;

        mc.gameMode.useItemOn(p, hand, hit);
        p.swing(hand);
        return true;
    }
}
