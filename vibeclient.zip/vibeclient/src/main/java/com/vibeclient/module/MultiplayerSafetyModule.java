package com.vibeclient.module;

import com.vibeclient.ServerAllowList;
import com.vibeclient.VibeClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;

/**
 * OPTIONAL. When switched on in the menu, keeps every other module OFF on multiplayer
 * servers unless you've allowed that server with #allow. Off by default, so all modules
 * work on every server. Singleplayer / your own world is unaffected.
 * It disables modules; it does not hide anything from anyone.
 */
public final class MultiplayerSafetyModule extends Module {
    private String lastNotified = "";

    public MultiplayerSafetyModule() {
        super("Multiplayer Safety", "Misc"); // OFF by default; turn it on in the menu if you want it
    }

    @Override
    public void onStartTick(Minecraft mc) {
        // Integrated server present = singleplayer/local. Connection without one = remote.
        if (mc.getConnection() == null || mc.getSingleplayerServer() != null) {
            lastNotified = "";
            return;
        }
        ServerData sd = mc.getCurrentServer();
        String host = sd == null ? "" : sd.ip;
        if (ServerAllowList.isAllowed(host)) return;

        VibeClient.MODULES.disableAllExcept(this);

        if (mc.player != null && !host.equals(lastNotified)) {
            lastNotified = host;
            mc.player.sendSystemMessage(Component.literal(
                    "[Vibe] Modules are off on this server. If it allows them, type #allow."));
        }
    }
}
