package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Shows hearts above every other player, their exact health, and a floating "-N" every time
 * they take damage. This class watches health changes each tick; HealthRenderer draws it.
 */
public class HealthIndicatorModule extends Module {
    public record Popup(UUID id, float amount, int tick) {}

    public static final int POPUP_LIFE = 60; // ticks a damage number stays on screen

    // Settings
    public boolean showNumber = true;
    public boolean showDamage = true;
    public int maxDistance = 64;

    private final Map<UUID, Float> last = new HashMap<>();
    private final List<Popup> popups = new ArrayList<>();
    private int tick;

    public HealthIndicatorModule() {
        super("Health Indicator", "Visuals");
        settings.add(Setting.ofBool("Show health number", () -> showNumber, v -> showNumber = v));
        settings.add(Setting.ofBool("Show damage popups", () -> showDamage, v -> showDamage = v));
        settings.add(Setting.ofInt("Max distance", () -> maxDistance, v -> maxDistance = v, 8, 128, 8));
    }

    public int getTick() { return tick; }
    public List<Popup> getPopups() { return popups; }

    @Override
    protected void onDisable() {
        last.clear();
        popups.clear();
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null) { last.clear(); popups.clear(); return; }
        tick++;

        Set<UUID> present = new HashSet<>();
        for (Player pl : mc.level.players()) {
            UUID id = pl.getUUID();
            present.add(id);
            float hp = pl.getHealth();
            Float prev = last.put(id, hp);
            if (prev != null && hp < prev - 0.01f) {
                popups.add(new Popup(id, prev - hp, tick));
            }
        }
        last.keySet().retainAll(present);
        popups.removeIf(p -> tick - p.tick() > POPUP_LIFE);
    }
}
