package com.vibeclient.module;

/**
 * Draws a tag above every other player: their name, the armor they wear, what they hold in
 * both hands, and the durability (%) of anything that can break. The drawing itself is in
 * NametagsRenderer; this class holds the on/off state and settings.
 */
public class NametagsModule extends Module {
    /** Read by the mixin that hides vanilla name tags. */
    public static volatile boolean hideVanillaActive;

    // Settings
    public boolean showArmor = true;
    public boolean showHands = true;
    public boolean hideVanilla = true;
    public int maxDistance = 128;

    public NametagsModule() {
        super("Nametags", "Visuals");
        settings.add(Setting.ofBool("Show armor", () -> showArmor, v -> showArmor = v));
        settings.add(Setting.ofBool("Show held items", () -> showHands, v -> showHands = v));
        settings.add(Setting.ofBool("Hide vanilla tags", () -> hideVanilla, v -> { hideVanilla = v; update(); }));
        settings.add(Setting.ofInt("Max distance", () -> maxDistance, v -> maxDistance = v, 16, 256, 16));
    }

    private void update() {
        hideVanillaActive = isEnabled() && hideVanilla;
    }

    @Override
    protected void onEnable() { update(); }

    @Override
    protected void onDisable() { update(); }
}
