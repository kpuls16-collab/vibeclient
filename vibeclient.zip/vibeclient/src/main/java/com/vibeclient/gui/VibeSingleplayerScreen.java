package com.vibeclient.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;

public final class VibeSingleplayerScreen extends ReferenceScreen {
    public VibeSingleplayerScreen() { super("Singleplayer", "reference_singleplayer"); }

    @Override protected void init() {
        // Clicking any listed world or the create button opens the real world picker.
        hitScaled(.455, .255, .33, .300,
                () -> Minecraft.getInstance().setScreen(new SelectWorldScreen(new VibeMainMenuScreen())));
        hitScaled(.445, .545, .33, .075,
                () -> Minecraft.getInstance().setScreen(new SelectWorldScreen(new VibeMainMenuScreen())));
        hitScaled(.445, .625, .33, .065,
                () -> Minecraft.getInstance().setScreen(new VibeMainMenuScreen()));
    }
}
