package com.vibeclient.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Shared full-screen artwork and invisible hit targets for the Vibe Client menu screens. */
public abstract class ReferenceScreen extends Screen {
    private final Identifier artwork;

    protected ReferenceScreen(String title, String texture) {
        super(Component.literal(title));
        this.artwork = Identifier.fromNamespaceAndPath("vibeclient", "textures/gui/" + texture + ".png");
    }

    protected void hit(int x, int y, int w, int h, Runnable action) {
        Button button = Button.builder(Component.empty(), b -> action.run())
                .bounds(x, y, w, h).build();
        button.setAlpha(0f);
        addRenderableWidget(button);
    }

    protected void hitScaled(double x, double y, double w, double h, Runnable action) {
        hit((int)(x * width), (int)(y * height), (int)(w * width), (int)(h * height), action);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        // Artwork is authored at 3:2; scale it to the active game window.
        g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, artwork,
                0, 0, 0.0f, 0.0f, width, height, 1536, 1024);
        super.extractRenderState(g, mouseX, mouseY, delta);
    }
}
