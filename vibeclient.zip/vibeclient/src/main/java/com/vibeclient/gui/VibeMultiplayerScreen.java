package com.vibeclient.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;

public final class VibeMultiplayerScreen extends ReferenceScreen {
    public VibeMultiplayerScreen() { super("Multiplayer", "reference_multiplayer"); }

    @Override protected void init() {
        // Keep server discovery, saved servers, direct connect and joining fully functional.
        hitScaled(.445, .295, .34, .075,
                () -> Minecraft.getInstance().setScreen(new JoinMultiplayerScreen(new VibeMainMenuScreen())));
        hitScaled(.445, .370, .34, .075,
                () -> Minecraft.getInstance().setScreen(new JoinMultiplayerScreen(new VibeMainMenuScreen())));
        hitScaled(.445, .445, .34, .075,
                () -> Minecraft.getInstance().setScreen(new JoinMultiplayerScreen(new VibeMainMenuScreen())));
        hitScaled(.445, .625, .34, .065,
                () -> Minecraft.getInstance().setScreen(new VibeMainMenuScreen()));
    }
}
