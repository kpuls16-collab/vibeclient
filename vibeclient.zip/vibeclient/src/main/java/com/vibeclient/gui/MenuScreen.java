package com.vibeclient.gui;

import com.vibeclient.VibeClient;
import com.vibeclient.module.Module;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Minimal first-pass menu using vanilla widgets. Custom styled GUI comes next. */
public class MenuScreen extends Screen {
    public MenuScreen() {
        super(Component.literal("Vibe Client"));
    }

    @Override
    protected void init() {
        int w = 160, h = 20, gap = 4;
        int y = this.height / 2 - (VibeClient.MODULES.all().size() * (h + gap)) / 2;
        for (Module m : VibeClient.MODULES.all()) {
            addRenderableWidget(Button.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).bounds(this.width / 2 - w / 2, y, w, h).build());
            y += h + gap;
        }
    }

    private static Component label(Module m) {
        return Component.literal(m.getName() + ": " + (m.isEnabled() ? "ON" : "OFF"));
    }
}
