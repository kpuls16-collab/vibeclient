package com.vibeclient.gui;

import com.vibeclient.ConfigManager;
import com.vibeclient.VibeClient;
import com.vibeclient.module.Module;
import com.vibeclient.module.Setting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Map;

/**
 * Vibe Client menu: dark panel, purple accent, sidebar (Modules / Settings / About),
 * toggle switches, and a per-module config page.
 *
 * Everything is drawn by hand in extractRenderState. Invisible vanilla buttons sit on top
 * of each clickable area and handle the clicks.
 */
public class MenuScreen extends Screen {
    // Colours (ARGB)
    private static final int PANEL = 0xF2110E1B;
    private static final int SIDEBAR = 0xF20B0912;
    private static final int BORDER = 0xFF6D3BE0;
    private static final int ROW = 0xFF1A1727;
    private static final int ROW_HOVER = 0xFF221E34;
    private static final int TAB_ON = 0xFF4B2BC4;
    private static final int ACCENT = 0xFF8B5CF6;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int SUB = 0xFF8E89A6;
    private static final int SWITCH_ON = 0xFF4F46E5;
    private static final int SWITCH_OFF = 0xFF34303F;
    private static final int KNOB_ON = 0xFFE0DBFF;
    private static final int KNOB_OFF = 0xFFB8B4C8;
    private static final int SMALL_BTN = 0xFF2A2640;

    private static final String[] TABS = {"Modules", "Settings", "About"};
    private static final int[] BADGES = {
            0xFF3B82F6, 0xFFF59E0B, 0xFFA855F7, 0xFF38BDF8,
            0xFF22C55E, 0xFF94A3B8, 0xFF818CF8, 0xFFEC4899};

    private static final Map<String, String> DESC = Map.ofEntries(
            Map.entry("Multiplayer Safety", "Turns modules off on servers unless allowed."),
            Map.entry("Auto Totem", "Refills your offhand totem after one pops."),
            Map.entry("Crystal Aura", "Places and breaks crystals while you right click."),
            Map.entry("ESP", "Highlights chosen blocks through walls (#esp_block)."),
            Map.entry("Sus Chunks", "Flags chunks with lots of player activity."),
            Map.entry("Freecam", "Fly a camera while your body stays put (V)."),
            Map.entry("Anchor Aura", "Places, charges and detonates respawn anchors."),
            Map.entry("Dtap Aura", "Swaps to your sword, then spams crystals."),
            Map.entry("Fast XP", "Throws a stack of XP bottles every few seconds."),
            Map.entry("X-Ray", "Shows only blocks you pick with #xray <block>."),
            Map.entry("Nametags", "Names with armor, held items and durability."),
            Map.entry("Health Indicator", "Hearts and damage numbers above players."));

    private int tab;                // 0 modules, 1 settings, 2 about
    private Module selected;        // module whose config page is open
    private boolean dirty = true;   // widgets need rebuilding

    private int px, py, pw, ph, sbw, cx0, cx1, cy0, cy1;

    public MenuScreen() {
        super(Component.literal("Vibe Client"));
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void init() {
        pw = Math.min(560, this.width - 16);
        ph = Math.min(400, this.height - 16);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        sbw = Math.max(86, Math.min(130, pw / 4));
        cx0 = px + sbw + 10;
        cx1 = px + pw - 10;
        cy0 = py + 40;
        cy1 = py + ph - 10;
        rebuild();
        dirty = false;
    }

    private static int rowHeight(int available, int n, int gap, int max) {
        if (n <= 0) return max;
        return Math.max(14, Math.min(max, (available - gap * (n - 1)) / n));
    }

    private List<Module> modules() { return VibeClient.MODULES.all(); }

    private void addBtn(int x, int y, int w, int h, Runnable action) {
        Button b = Button.builder(Component.empty(), btn -> action.run()).bounds(x, y, w, h).build();
        b.setAlpha(0f); // invisible; we draw everything ourselves
        addRenderableWidget(b);
    }

    private void rebuild() {
        clearWidgets();

        addBtn(px + pw - 30, py + 8, 20, 20, this::onClose);   // close
        addBtn(px + pw - 54, py + 8, 20, 20, this::onClose);   // minimise (closes for now)

        for (int i = 0; i < TABS.length; i++) {
            final int t = i;
            addBtn(px + 6, tabY(i), sbw - 12, 24, () -> { tab = t; selected = null; dirty = true; });
        }

        if (tab == 0 && selected == null) {
            List<Module> mods = modules();
            int gap = 3;
            int rh = rowHeight(cy1 - cy0, mods.size(), gap, 34);
            for (int i = 0; i < mods.size(); i++) {
                final Module m = mods.get(i);
                int y = cy0 + i * (rh + gap);
                if (!m.getSettings().isEmpty()) {
                    addBtn(cfgX(), y + (rh - 16) / 2, 40, 16, () -> { selected = m; dirty = true; });
                }
                addBtn(cx0, y, cx1 - cx0, rh, m::toggle);
            }
        } else if (tab == 0) {
            addBtn(cx0, cy0, cx1 - cx0, 22, () -> { selected = null; dirty = true; });
            List<Setting> list = selected.getSettings();
            int gap = 3;
            int sy0 = cy0 + 28;
            int rh = rowHeight(cy1 - sy0, list.size(), gap, 28);
            for (int i = 0; i < list.size(); i++) {
                final Setting s = list.get(i);
                int y = sy0 + i * (rh + gap);
                if (s.isBool()) {
                    addBtn(cx0, y, cx1 - cx0, rh, () -> s.adjust(1));
                } else {
                    addBtn(minusX(), y + (rh - 18) / 2, 18, 18, () -> s.adjust(-1));
                    addBtn(plusX(), y + (rh - 18) / 2, 18, 18, () -> s.adjust(1));
                }
            }
        } else if (tab == 1) {
            addBtn(cx0, cy0, cx1 - cx0, 26, () -> { for (Module m : modules()) m.setEnabled(false); });
        }
    }

    private int tabY(int i) { return py + 78 + i * 28; }
    private int toggleX() { return cx1 - 8 - 34; }
    private int cfgX() { return toggleX() - 48; }
    private int plusX() { return cx1 - 8 - 18; }
    private int minusX() { return plusX() - 18 - 64 - 8; }

    // ------------------------------------------------------------------ drawing helpers

    private static void rrect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
        g.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - d * d));
            g.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, color);
            g.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, color);
        }
    }

    private void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(this.font, s, x, y, color, true);
    }

    private void textCentered(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        text(g, s, cx - this.font.width(s) / 2, y, color);
    }

    private String fit(String s, int maxW) {
        if (this.font.width(s) <= maxW) return s;
        while (s.length() > 1 && this.font.width(s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private static boolean inside(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    private void drawSwitch(GuiGraphicsExtractor g, int x, int y, boolean on) {
        rrect(g, x, y, x + 34, y + 16, 8, on ? SWITCH_ON : SWITCH_OFF);
        int kx = on ? x + 34 - 14 : x + 2;
        rrect(g, kx, y + 2, kx + 12, y + 14, 6, on ? KNOB_ON : KNOB_OFF);
    }

    // ---- Pixel-art module icons (one character = one pixel) ----
    private static final String[] CHEST = {
            "OOOOOOOOOOO",
            "OTTTTTTTTTO",
            "OWWWWWWWWWO",
            "ODDDDDDDDDO",
            "OWWWWMWWWWO",
            "OWWWWMWWWWO",
            "OWWWWWWWWWO",
            "OWWWWWWWWWO",
            "OOOOOOOOOOO"};
    private static final String[] FURNACE = {
            "OOOOOOOOOO",
            "OLLLLLLLLO",
            "OSSSSSSSSO",
            "OSKKKKKKSO",
            "OSKYFFYKSO",
            "OSKFYYFKSO",
            "OSKKKKKKSO",
            "OSSSSSSSSO",
            "OSSSSSSSSO",
            "OOOOOOOOOO"};
    private static final String[] FLY = {
            "...rrrrrr...",
            "...sEssEs...",
            "...ssssss...",
            "ssbbbbbbbbss",
            "...bbbbbb...",
            "...bbbbbb...",
            "...bbbbbb...",
            "...pppppp...",
            "...pppppp...",
            "...pp..pp...",
            "..w..w..w...",
            "....w..w...."};
    private static final String[] ANCHOR = {
            "OOOOOOOOOOOO",
            "OnnnnnnnnnnO",
            "OnnjJJJJjnnO",
            "OnnjJJJJjnnO",
            "OnnnnnnnnnnO",
            "OncnnnnnncnO",
            "OnnnnncnnnnO",
            "OnnnnnnnncnO",
            "OncnnnnnnnnO",
            "OnnnnncnnnnO",
            "OnnnnnnnnnnO",
            "OOOOOOOOOOOO"};
    private static final String[] DTAP = {
            ".rrr.........rrr..........",
            ".ssE.........Ess..........",
            ".sss.........sss..........",
            ".bbb........yRRR....X.....",
            ".bbbshlllllYYRRR...XxX....",
            ".bbb........yRRR..XxxxX...",
            ".ppp.........ppp...XxX....",
            ".ppp.........ppp....X.....",
            ".p.p.........p.p.qqqqqqq..",
            ".p.p.........p.p.nnnnnnn..",
            "gggggggggggggggggggggggggg"};

    private static final String[] CRYSTAL = {
            ".....OO.....",
            "....OxxO....",
            "...OxxxxO...",
            "..OxxzzxxO..",
            ".OxxzzzzxxO.",
            "OxxxzzzzxxxO",
            "OXxxzzzzxxXO",
            ".OXXxzzxXXO.",
            "..OXXxxXXO..",
            "...OXXXXO...",
            "....OXXO....",
            ".....OO....."};
    private static final String[] TOTEM = {
            "...BBBBB...",
            "..BaaaaaB..",
            "..BakakaB..",
            "..BaaGaaB..",
            "BBBBBBBBBBB",
            "BaaaaaaaaaB",
            "BGaaaaaaaGB",
            "BBBBaaaBBBB",
            "...BaaaB...",
            "...BaGaB...",
            "...BaaaB...",
            "...BaBaB...",
            "...BBBBB..."};
    private static final String[] CHUNK = {
            "OOOOOOOOOOOOO",
            "O...u...u...O",
            "O...u...u...O",
            "O...u...u...O",
            "OuuuuuuuuuuuO",
            "O...uyyyu...O",
            "O...uyyyu...O",
            "O...uyyyu...O",
            "OuuuuuuuuuuuO",
            "O...u...u...O",
            "O...u...u...O",
            "O...u...u...O",
            "OOOOOOOOOOOOO"};
    private static final String[] SHIELD = {
            "IIIIIIIIIII",
            "IWWDWWWDWWI",
            "IWWDWWWDWWI",
            "IWWDMMMDWWI",
            "IWWDMMMDWWI",
            "IWWDWWWDWWI",
            "IWWDWWWDWWI",
            ".IWDWWWDWI.",
            ".IWDWWWDWI.",
            "..IWWWWWI..",
            "...IWWWI...",
            "....IWI....",
            ".....I....."};

    private static final String[] XPBOTTLE = {
            "...BBB...",
            "...BBB...",
            "...OwO...",
            "...OvO...",
            "..OOvOO..",
            ".OvvvvvO.",
            "OvvwvvvVO",
            "OvwvvvvVO",
            "OvvvvvVVO",
            ".OvvvVVO.",
            "..OOOOO.."};

    private static final String[] XRAY = {
            "OOOOOOOOOOO",
            "OSSSSSSSSSO",
            "OSNNSSKSSSO",
            "OSNNSSSSNNO",
            "OSSSSKSSNNO",
            "OSKSSSSSSSO",
            "OSSSNNSSKSO",
            "OSSSNNSSSSO",
            "OSNNSSSSSSO",
            "OSNNSKSSSSO",
            "OOOOOOOOOOO"};

    private static final String[] NAMETAG = {
            "..OOOOOOOOOO",
            ".OwwwwwwwwwO",
            "OwwOwwwwwwwO",
            ".OwwKKKKKwwO",
            ".OwwwwwwwwwO",
            ".OwwKKKKwwwO",
            ".OwwwwwwwwwO",
            "..OOOOOOOOOO"};

    private static final String[] HEARTICON = {
            ".OOO...OOO.",
            "OeeeOOOeeeO",
            "OefeeeeeeeO",
            "OeeeeeeeeeO",
            "OeeeeeeeeeO",
            ".OeeeeeeeO.",
            "..OeeeeeO..",
            "...OeeeO...",
            "....OeO....",
            ".....O....."};

    /** Draws the custom icon for a module. Returns false if it has none (a letter badge is used). */
    private boolean drawIcon(GuiGraphicsExtractor g, String name, int x, int y, int w, int h) {
        double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 400.0);
        int a1 = (int) (50 + 60 * pulse);
        int a2 = (int) (100 + 110 * pulse);
        switch (name) {
            case "Crystal Aura" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, CRYSTAL, x + (w - 12) / 2, y + (h - CRYSTAL.length) / 2, 0xE879F9, a1, a2);
                return true;
            }
            case "Auto Totem" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, TOTEM, x + (w - 11) / 2, y + (h - TOTEM.length) / 2, 0xFFD34D, a1 / 2, a2 / 2);
                return true;
            }
            case "Sus Chunks" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, CHUNK, x + (w - 13) / 2, y + (h - CHUNK.length) / 2, 0xFFC857, a1, a2);
                return true;
            }
            case "Multiplayer Safety" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, SHIELD, x + (w - 11) / 2, y + (h - SHIELD.length) / 2, 0x4ADE80, a1 / 2, a2 / 2);
                return true;
            }
            case "Fast XP" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, XPBOTTLE, x + (w - 9) / 2, y + (h - XPBOTTLE.length) / 2, 0x7CFF6B, a1, a2);
                return true;
            }
            case "X-Ray" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, XRAY, x + (w - 11) / 2, y + (h - XRAY.length) / 2, 0x4DE3E3, a1, a2);
                return true;
            }
            case "Nametags" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, NAMETAG, x + (w - 12) / 2, y + (h - NAMETAG.length) / 2, 0x9AD1FF, a1, a2);
                return true;
            }
            case "Health Indicator" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, HEARTICON, x + (w - 11) / 2, y + (h - HEARTICON.length) / 2, 0xFF4D4D, a1, a2);
                return true;
            }
            case "ESP" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, CHEST, x + 7, y + (h - CHEST.length) / 2, 0xFFD04D, a1, a2);
                drawPixelIcon(g, FURNACE, x + 22, y + (h - FURNACE.length) / 2, 0xFF8A3D, a1, a2);
                return true;
            }
            case "Freecam" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF1F3B63);
                drawPixelIcon(g, FLY, x + (w - 12) / 2, y + (h - FLY.length) / 2, 0, 0, 0);
                return true;
            }
            case "Anchor Aura" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                drawPixelIcon(g, ANCHOR, x + (w - 12) / 2, y + (h - ANCHOR.length) / 2, 0xA855F7, a1, a2);
                return true;
            }
            case "Dtap Aura" -> {
                rrect(g, x, y, x + w, y + h, 5, 0xFF14111F);
                int ix = x + (w - 26) / 2, iy = y + (h - DTAP.length) / 2;
                // soft glow behind the crystal
                g.fill(ix + 17, iy + 1, ix + 24, iy + 8, (a1 << 24) | 0xB02FD6);
                g.fill(ix + 18, iy + 2, ix + 23, iy + 7, (a2 << 24) | 0xB02FD6);
                drawPixelIcon(g, DTAP, ix, iy, 0, 0, 0);
                return true;
            }
            default -> { return false; }
        }
    }

    private void drawPixelIcon(GuiGraphicsExtractor g, String[] rows, int x, int y, int glowRgb, int a1, int a2) {
        int w = rows[0].length(), h = rows.length;
        if (a1 > 0) {
            g.fill(x - 2, y - 2, x + w + 2, y + h + 2, (a1 << 24) | glowRgb);
            g.fill(x - 1, y - 1, x + w + 1, y + h + 1, (a2 << 24) | glowRgb);
        }
        for (int r = 0; r < h; r++) {
            for (int c = 0; c < w; c++) {
                int color = switch (rows[r].charAt(c)) {
                    case 'O' -> 0xFF000000 | glowRgb;   // outline glows in the icon's colour
                    // chest
                    case 'T' -> 0xFFD9A55C;
                    case 'W' -> 0xFFB07A3A;
                    case 'D' -> 0xFF7A4E22;
                    case 'M' -> 0xFFE6E6E6;
                    // furnace
                    case 'L' -> 0xFFB5B5B5;
                    case 'S' -> 0xFF8C8C8C;
                    case 'K' -> 0xFF3A3A3A;
                    case 'F' -> 0xFFFF9A2E;
                    case 'Y' -> 0xFFFFD35A;
                    // players
                    case 'r' -> 0xFF4A2F1B;   // hair
                    case 's' -> 0xFFD9A47C;   // skin
                    case 'E' -> 0xFF1A1A1A;   // eye
                    case 'b' -> 0xFF2FB7C9;   // your shirt
                    case 'R' -> 0xFFD94A4A;   // enemy shirt
                    case 'p' -> 0xFF3A3FA8;   // trousers
                    case 'w' -> 0xFFCFE3FF;   // wind
                    // dtap scene
                    case 'h' -> 0xFF7A4E22;   // sword guard
                    case 'l' -> 0xFFBFE9FF;   // blade
                    case 'y' -> 0xFFFFA43A;   // hit spark
                    case 'X' -> 0xFFB02FD6;   // crystal edge
                    case 'x' -> 0xFFF2A6FF;   // crystal core
                    case 'q' -> 0xFF5A3A99;   // obsidian edge
                    case 'g' -> 0xFF4C8C3A;   // grass
                    // crystal, totem, chunk, shield
                    case 'z' -> 0xFFFFE9FF;   // crystal core
                    case 'a' -> 0xFFE8B730;   // totem gold
                    case 'B' -> 0xFF5A3A12;   // totem outline
                    case 'G' -> 0xFF3DDC84;   // totem gem
                    case 'k' -> 0xFF1A1A1A;   // totem eye
                    case 'u' -> 0xFF4A4470;   // chunk grid line
                    case 'I' -> 0xFFC9C9D3;   // shield iron rim
                    case 'v' -> 0xFF5CE65C;   // xp bottle liquid
                    case 'N' -> 0xFF5CF2F2;   // diamond
                    case 'e' -> 0xFFE8333A;   // heart
                    case 'f' -> 0xFFFF9A9A;   // heart highlight
                    case 'V' -> 0xFF2FA84F;   // xp bottle liquid (shade)
                    // anchor
                    case 'n' -> 0xFF1B1030;   // obsidian
                    case 'c' -> 0xFF6D2DD1;   // crying obsidian
                    case 'j' -> 0xFFFFC857;   // glowstone
                    case 'J' -> 0xFFFFE9A0;   // glowstone bright
                    default -> 0;
                };
                if (color != 0) g.fill(x + c, y + r, x + c + 1, y + r + 1, color);
            }
        }
    }

    private static String initials(String name) {
        String[] parts = name.split(" ");
        if (parts.length >= 2) return ("" + parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
        return name.substring(0, Math.min(2, name.length())).toUpperCase();
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (dirty) { rebuild(); dirty = false; }
        super.extractRenderState(g, mouseX, mouseY, delta);

        // Panel + border
        rrect(g, px - 1, py - 1, px + pw + 1, py + ph + 1, 6, BORDER);
        rrect(g, px, py, px + pw, py + ph, 6, PANEL);

        drawSidebar(g, mouseX, mouseY);
        drawHeader(g, mouseX, mouseY);

        if (tab == 0 && selected == null) drawModules(g, mouseX, mouseY);
        else if (tab == 0) drawModuleConfig(g, mouseX, mouseY);
        else if (tab == 1) drawSettingsTab(g, mouseX, mouseY);
        else drawAbout(g);
    }

    private void drawSidebar(GuiGraphicsExtractor g, int mx, int my) {
        rrect(g, px + 1, py + 1, px + sbw, py + ph - 1, 5, SIDEBAR);
        g.fill(px + sbw, py + 1, px + sbw + 1, py + ph - 1, 0xFF241F36);

        // Logo
        int lx = px + sbw / 2 - 14;
        rrect(g, lx, py + 12, lx + 28, py + 40, 6, ACCENT);
        textCentered(g, "V", px + sbw / 2, py + 22, WHITE);
        textCentered(g, "Vibe Client", px + sbw / 2, py + 48, WHITE);
        textCentered(g, "v0.1.0", px + sbw / 2, py + 60, SUB);

        for (int i = 0; i < TABS.length; i++) {
            int y = tabY(i);
            boolean on = i == tab;
            boolean hover = inside(mx, my, px + 6, y, px + sbw - 6, y + 24);
            if (on) rrect(g, px + 6, y, px + sbw - 6, y + 24, 5, TAB_ON);
            else if (hover) rrect(g, px + 6, y, px + sbw - 6, y + 24, 5, ROW);
            rrect(g, px + 14, y + 8, px + 22, y + 16, 2, on ? WHITE : SUB);
            text(g, TABS[i], px + 28, y + 8, on ? WHITE : SUB);
        }
    }

    private void drawHeader(GuiGraphicsExtractor g, int mx, int my) {
        String title = tab == 0 ? (selected == null ? "Modules" : selected.getName()) : TABS[tab];
        text(g, title, cx0 + 2, py + 14, WHITE);
        g.fill(cx0, py + 30, cx1, py + 31, ACCENT);

        boolean hc = inside(mx, my, px + pw - 30, py + 8, px + pw - 10, py + 28);
        boolean hm = inside(mx, my, px + pw - 54, py + 8, px + pw - 34, py + 28);
        rrect(g, px + pw - 30, py + 8, px + pw - 10, py + 28, 4, hc ? 0xFF3A2A66 : 0xFF1E1B2E);
        rrect(g, px + pw - 54, py + 8, px + pw - 34, py + 28, 4, hm ? 0xFF3A2A66 : 0xFF1E1B2E);
        textCentered(g, "X", px + pw - 20, py + 14, WHITE);
        textCentered(g, "-", px + pw - 44, py + 14, WHITE);
    }

    private void drawModules(GuiGraphicsExtractor g, int mx, int my) {
        List<Module> mods = modules();
        int gap = 3;
        int rh = rowHeight(cy1 - cy0, mods.size(), gap, 34);
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int y = cy0 + i * (rh + gap);
            boolean hover = inside(mx, my, cx0, y, cx1, y + rh);
            rrect(g, cx0, y, cx1, y + rh, 5, hover ? ROW_HOVER : ROW);

            // Badge
            int slot = 40;
            int bs = Math.min(22, rh - 4);
            int by = y + (rh - bs) / 2;
            boolean customIcon = bs >= 20 && drawIcon(g, m.getName(), cx0 + 6, by, slot, bs);
            if (!customIcon) {
                rrect(g, cx0 + 12, by, cx0 + 40, by + bs, 5, BADGES[i % BADGES.length]);
                textCentered(g, initials(m.getName()), cx0 + 26, by + (bs - 8) / 2, WHITE);
            }

            int tx = cx0 + 6 + slot + 8;
            boolean hasCfg = !m.getSettings().isEmpty();
            int maxW = (hasCfg ? cfgX() : toggleX()) - tx - 6;
            if (rh >= 26) {
                int ny = (rh - 20) / 2;
                text(g, fit(m.getName(), maxW), tx, y + ny, WHITE);
                text(g, fit(DESC.getOrDefault(m.getName(), ""), maxW), tx, y + ny + 11, SUB);
            } else {
                text(g, fit(m.getName(), maxW), tx, y + (rh - 8) / 2, WHITE);
            }

            if (hasCfg) {
                int cy = y + (rh - 16) / 2;
                boolean hc = inside(mx, my, cfgX(), cy, cfgX() + 40, cy + 16);
                rrect(g, cfgX(), cy, cfgX() + 40, cy + 16, 4, hc ? 0xFF3A2A66 : SMALL_BTN);
                textCentered(g, "Config", cfgX() + 20, cy + 4, hc ? WHITE : SUB);
            }
            drawSwitch(g, toggleX(), y + (rh - 16) / 2, m.isEnabled());
        }
    }

    private void drawModuleConfig(GuiGraphicsExtractor g, int mx, int my) {
        boolean hb = inside(mx, my, cx0, cy0, cx1, cy0 + 22);
        rrect(g, cx0, cy0, cx1, cy0 + 22, 5, hb ? ROW_HOVER : ROW);
        text(g, "< Back to modules", cx0 + 10, cy0 + 7, WHITE);

        List<Setting> list = selected.getSettings();
        int gap = 3;
        int sy0 = cy0 + 28;
        int rh = rowHeight(cy1 - sy0, list.size(), gap, 28);
        for (int i = 0; i < list.size(); i++) {
            Setting s = list.get(i);
            int y = sy0 + i * (rh + gap);
            boolean hover = inside(mx, my, cx0, y, cx1, y + rh);
            rrect(g, cx0, y, cx1, y + rh, 5, hover ? ROW_HOVER : ROW);
            text(g, fit(s.name(), minusX() - cx0 - 20), cx0 + 10, y + (rh - 8) / 2, WHITE);

            if (s.isBool()) {
                drawSwitch(g, toggleX(), y + (rh - 16) / 2, s.boolValue());
            } else {
                int by = y + (rh - 18) / 2;
                boolean hm = inside(mx, my, minusX(), by, minusX() + 18, by + 18);
                boolean hp = inside(mx, my, plusX(), by, plusX() + 18, by + 18);
                rrect(g, minusX(), by, minusX() + 18, by + 18, 4, hm ? 0xFF3A2A66 : SMALL_BTN);
                rrect(g, plusX(), by, plusX() + 18, by + 18, 4, hp ? 0xFF3A2A66 : SMALL_BTN);
                textCentered(g, "<", minusX() + 9, by + 5, WHITE);
                textCentered(g, ">", plusX() + 9, by + 5, WHITE);
                int vcx = (minusX() + 18 + plusX()) / 2;
                textCentered(g, s.display(), vcx, y + (rh - 8) / 2, ACCENT);
            }
        }
        text(g, "Changes are saved when you close the menu.", cx0 + 2, cy1 - 8, SUB);
    }

    private void drawSettingsTab(GuiGraphicsExtractor g, int mx, int my) {
        boolean hb = inside(mx, my, cx0, cy0, cx1, cy0 + 26);
        rrect(g, cx0, cy0, cx1, cy0 + 26, 5, hb ? 0xFF5A2A4A : 0xFF3B1F36);
        textCentered(g, "Turn off all modules", (cx0 + cx1) / 2, cy0 + 9, WHITE);

        int y = cy0 + 40;
        text(g, "Open menu: Right Shift", cx0 + 4, y, WHITE);
        text(g, "Freecam: V (change both in Controls)", cx0 + 4, y + 14, WHITE);
        text(g, "ESP: type #esp_diamond_ore in chat", cx0 + 4, y + 28, SUB);
        text(g, "Sus Chunks: type #sus in chat", cx0 + 4, y + 42, SUB);
        text(g, "Settings file: config/vibeclient.properties", cx0 + 4, y + 62, SUB);
    }

    private void drawAbout(GuiGraphicsExtractor g) {
        int y = cy0 + 4;
        text(g, "Vibe Client v0.1.0", cx0 + 4, y, WHITE);
        text(g, "Minecraft 26.1.2 - Fabric", cx0 + 4, y + 14, SUB);
        text(g, "Modules only run while switched on.", cx0 + 4, y + 36, SUB);
        text(g, "Check each server's rules before using them.", cx0 + 4, y + 50, SUB);
    }

    @Override
    public void onClose() {
        ConfigManager.save();
        super.onClose();
    }
}
