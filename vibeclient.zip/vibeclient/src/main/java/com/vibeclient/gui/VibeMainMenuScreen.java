package com.vibeclient.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import com.vibeclient.gui.MenuScreen;

public final class VibeMainMenuScreen extends ReferenceScreen {
    public VibeMainMenuScreen() { super("Vibe Client", "reference_main_menu"); }

    @Override protected void init() {
        // The hit regions follow the four large buttons in the supplied main-menu reference.
        hitScaled(.375, .535, .28, .065, () -> Minecraft.getInstance().setScreen(new VibeSingleplayerScreen()));
        hitScaled(.375, .610, .28, .065, () -> Minecraft.getInstance().setScreen(new VibeMultiplayerScreen()));
        hitScaled(.375, .685, .28, .065, () -> Minecraft.getInstance().setScreen(new MenuScreen()));
        hitScaled(.375, .760, .28, .065, () -> Minecraft.getInstance().setScreen(new OptionsScreen(this, Minecraft.getInstance().options)));
    }
}
