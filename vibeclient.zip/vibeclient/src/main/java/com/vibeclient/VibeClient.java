package com.vibeclient;

import com.mojang.blaze3d.platform.InputConstants;
import com.vibeclient.gui.MenuScreen;
import com.vibeclient.module.FreecamModule;
import com.vibeclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;

public class VibeClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyMapping menuKey;
    private static KeyMapping freecamKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.vibeclient.menu", InputConstants.KEY_RIGHT_SHIFT, KeyMapping.Category.MISC));

        // "#esp_<block>", "#allow" chat commands are handled locally and never sent to the server.
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !(EspCommands.handle(msg) || SusCommands.handle(msg) || ServerCommands.handle(msg)));

        EspRenderer.get().register();
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> EspRenderer.get().close());

        freecamKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.vibeclient.freecam", InputConstants.KEY_V, KeyMapping.Category.MISC));

        ClientTickEvents.START_CLIENT_TICK.register(MODULES::startTick);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new MenuScreen());
            }
            while (freecamKey.consumeClick()) {
                MODULES.get(FreecamModule.class).toggle();
            }
            MODULES.tick(mc);
        });
    }
}
