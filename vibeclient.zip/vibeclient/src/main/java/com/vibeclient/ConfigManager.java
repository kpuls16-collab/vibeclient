package com.vibeclient;

import com.vibeclient.module.FreecamModule;
import com.vibeclient.module.Module;
import com.vibeclient.module.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves which modules are on and every setting to config/vibeclient.properties. */
public final class ConfigManager {
    private ConfigManager() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("vibeclient.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) {
            p.load(in);
        } catch (IOException e) {
            return; // first run: nothing saved yet
        }
        for (Module m : VibeClient.MODULES.all()) {
            for (Setting s : m.getSettings()) {
                String v = p.getProperty(m.getName() + "." + s.name());
                if (v != null) s.deserialize(v);
            }
            // Freecam always starts off.
            String en = p.getProperty("enabled." + m.getName());
            if (en != null && !(m instanceof FreecamModule)) m.setEnabled(Boolean.parseBoolean(en));
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : VibeClient.MODULES.all()) {
            p.setProperty("enabled." + m.getName(), Boolean.toString(m.isEnabled()));
            for (Setting s : m.getSettings()) p.setProperty(m.getName() + "." + s.name(), s.serialize());
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "Vibe Client settings");
        } catch (IOException ignored) {}
    }
}
