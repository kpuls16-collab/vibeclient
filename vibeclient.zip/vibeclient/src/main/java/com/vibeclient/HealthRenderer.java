package com.vibeclient;

import com.vibeclient.module.HealthIndicatorModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

/**
 * Draws hearts, the health number and floating damage numbers above players on the HUD layer.
 * Uses the same screen projection as NametagsRenderer (follows the camera entity's eye).
 */
public final class HealthRenderer {
    private HealthRenderer() {}

    private static final String[] HEART = {
            ".XX.XX.",
            "XXXXXXX",
            "XXXXXXX",
            ".XXXXX.",
            "..XXX..",
            "...X..."};
    private static final int CELL = 8;
    private static final int FULL = 0xFFE8333A;
    private static final int HIGHLIGHT = 0xFFFF9A9A;
    private static final int EMPTY = 0xFF3A1A1F;

    public static void render(GuiGraphicsExtractor g, float partial) {
        HealthIndicatorModule hm = VibeClient.MODULES.get(HealthIndicatorModule.class);
        if (!hm.isEnabled()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Entity cam = mc.getCameraEntity();
        if (cam == null) return;

        Vec3 eye = cam.getEyePosition(partial);
        double yaw = Math.toRadians(cam.getViewYRot(partial));
        double pitch = Math.toRadians(cam.getViewXRot(partial));
        Vec3 f = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 r = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 u = r.cross(f);

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) sw / sh;
        double maxDistSq = (double) hm.maxDistance * hm.maxDistance;

        for (Player pl : mc.level.players()) {
            if (pl == cam || !pl.isAlive()) continue;

            Vec3 head = pl.getPosition(partial).add(0, pl.getBbHeight() + 0.45, 0);
            Vec3 d = head.subtract(eye);
            if (d.lengthSqr() > maxDistSq) continue;
            double z = d.dot(f);
            if (z < 0.1) continue;
            int sx = (int) Math.round(sw / 2.0 + (d.dot(r) / z) / (tanHalf * aspect) * (sw / 2.0));
            int sy = (int) Math.round(sh / 2.0 - (d.dot(u) / z) / tanHalf * (sh / 2.0));
            if (sx < -200 || sx > sw + 200 || sy < -100 || sy > sh + 100) continue;

            draw(g, mc, hm, pl, sx, sy, partial);
        }
    }

    private static void draw(GuiGraphicsExtractor g, Minecraft mc, HealthIndicatorModule hm, Player pl,
                             int cx, int bottomY, float partial) {
        float hp = Math.max(0f, pl.getHealth());
        float max = Math.max(1f, pl.getMaxHealth());
        float absorb = pl.getAbsorptionAmount();

        // ---- hearts (one row of 10 = 20 health) ----
        int hearts = 10;
        float perHeart = Math.max(2f, max / 10f);       // health points each heart stands for
        int rowW = hearts * CELL;
        int x0 = cx - rowW / 2;
        int y = bottomY - 8;
        g.fill(x0 - 2, y - 1, x0 + rowW + 1, y + 8, 0x70000000);
        for (int i = 0; i < hearts; i++) {
            float filled = hp - i * perHeart;
            int state = filled >= perHeart * 0.75f ? 2 : filled >= perHeart * 0.25f ? 1 : 0;
            drawHeart(g, x0 + i * CELL, y, state);
        }

        // ---- number ----
        int textY = y - 11;
        if (hm.showNumber) {
            String t = num(hp) + " / " + num(max);
            int tw = mc.font.width(t);
            int color = hp > max * 0.6f ? 0xFF55FF55 : hp > max * 0.3f ? 0xFFFFFF55 : 0xFFFF5555;
            g.text(mc.font, t, cx - tw / 2, textY, color, true);
            if (absorb > 0.01f) {
                String a = " +" + num(absorb);
                g.text(mc.font, a, cx + tw / 2, textY, 0xFFFFD34D, true);
            }
        }

        // ---- floating damage numbers ----
        if (hm.showDamage) {
            for (HealthIndicatorModule.Popup p : hm.getPopups()) {
                if (!p.id().equals(pl.getUUID())) continue;
                float age = (hm.getTick() - p.tick()) + partial;
                if (age < 0 || age > HealthIndicatorModule.POPUP_LIFE) continue;
                int alpha = Math.max(16, (int) (255 * (1f - age / HealthIndicatorModule.POPUP_LIFE)));
                String t = "-" + num(p.amount());
                int ty = textY - 12 - (int) (age * 0.5f);
                g.text(mc.font, t, cx - mc.font.width(t) / 2, ty, (alpha << 24) | 0xFF5555, true);
            }
        }
    }

    /** state: 0 = empty, 1 = half, 2 = full */
    private static void drawHeart(GuiGraphicsExtractor g, int x, int y, int state) {
        for (int r = 0; r < HEART.length; r++) {
            for (int c = 0; c < HEART[r].length(); c++) {
                if (HEART[r].charAt(c) != 'X') continue;
                boolean filled = state == 2 || (state == 1 && c <= 3);
                int color = filled ? (r == 1 && c == 1 ? HIGHLIGHT : FULL) : EMPTY;
                g.fill(x + c, y + r, x + c + 1, y + r + 1, color);
            }
        }
    }

    private static String num(float v) {
        return v == Math.floor(v) ? Integer.toString((int) v) : String.format(Locale.ROOT, "%.1f", v);
    }
}
