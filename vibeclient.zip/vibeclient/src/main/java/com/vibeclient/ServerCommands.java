package com.vibeclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;

import java.util.Locale;

/**
 * Chat commands (never sent to the server):
 *   #allow       allow Vibe Client modules on the server you're on
 *   #disallow    remove the server you're on from the list
 *   #allowlist   show allowed servers
 */
public final class ServerCommands {
    private ServerCommands() {}

    /** @return true if the message was handled and should NOT be sent. */
    public static boolean handle(String message) {
        String msg = message.trim().toLowerCase(Locale.ROOT);
        if (!msg.equals("#allow") && !msg.equals("#disallow") && !msg.equals("#allowlist")) return false;

        Minecraft mc = Minecraft.getInstance();
        ServerData sd = mc.getCurrentServer();

        switch (msg) {
            case "#allowlist" -> {
                var all = ServerAllowList.all();
                say(all.isEmpty() ? "No servers allowed yet. Join one and type #allow." : "Allowed servers: " + String.join(", ", all));
            }
            case "#allow" -> {
                if (sd == null) say("Not on a multiplayer server.");
                else say(ServerAllowList.add(sd.ip) ? "Modules allowed on " + sd.ip : "Already allowed on " + sd.ip);
            }
            case "#disallow" -> {
                if (sd == null) say("Not on a multiplayer server.");
                else say(ServerAllowList.remove(sd.ip) ? "Modules no longer allowed on " + sd.ip : sd.ip + " wasn't in the list.");
            }
        }
        return true;
    }

    private static void say(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[Vibe] " + text));
    }
}
