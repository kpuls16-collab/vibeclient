package com.vibeclient;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.vibeclient.module.EspModule;
import com.vibeclient.module.FreecamModule;
import com.vibeclient.module.SusChunksModule;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Draws filled boxes through walls using a custom pipeline with no depth test.
 * Based on the Fabric docs "Rendering in the World" page for 26.1.2.
 * All 26.1-specific rendering code lives in this one file.
 */
public final class EspRenderer {
    private static final EspRenderer INSTANCE = new EspRenderer();
    public static EspRenderer get() { return INSTANCE; }

    private static final float ALPHA = 0.35f;

    /** One translucent box to draw through walls (world coordinates). */
    public record Box(float x0, float y0, float z0, float x1, float y1, float z1,
                      float r, float g, float b, float a) {}

    private static final RenderPipeline FILLED_THROUGH_WALLS = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath("vibeclient", "pipeline/esp_through_walls"))
                    .withDepthStencilState(Optional.empty())
                    .build());

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private volatile List<Box> state = List.of();
    private BufferBuilder buffer;
    private MappableRingBuffer vertexBuffer;

    private EspRenderer() {}

    public void register() {
        LevelRenderEvents.END_EXTRACTION.register(this::extract);
        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(this::renderAndDraw);
    }

    // ---- Extraction phase: grab immutable data ----
    private void extract(LevelExtractionContext context) {
        VibeClient.MODULES.get(FreecamModule.class).frameUpdate();

        List<Box> out = new ArrayList<>();
        EspModule esp = VibeClient.MODULES.get(EspModule.class);
        if (esp.isEnabled()) {
            for (EspModule.Hit h : esp.getFound()) {
                out.add(new Box(h.x(), h.y(), h.z(), h.x() + 1, h.y() + 1, h.z() + 1, h.r(), h.g(), h.b(), ALPHA));
            }
        }
        SusChunksModule sus = VibeClient.MODULES.get(SusChunksModule.class);
        if (sus.isEnabled()) out.addAll(sus.getBoxes());
        state = out;
    }

    // ---- Drawing phase ----
    private void renderAndDraw(LevelRenderContext context) {
        List<Box> hits = state;
        if (hits.isEmpty()) return;

        PoseStack matrices = context.poseStack();
        Vec3 camera = context.levelState().cameraRenderState.pos;

        matrices.pushPose();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        if (buffer == null) {
            buffer = new BufferBuilder(ALLOCATOR, FILLED_THROUGH_WALLS.getVertexFormatMode(), FILLED_THROUGH_WALLS.getVertexFormat());
        }
        for (Box h : hits) {
            box(matrices.last().pose(), buffer, h.x0(), h.y0(), h.z0(), h.x1(), h.y1(), h.z1(), h.r(), h.g(), h.b(), h.a());
        }
        matrices.popPose();

        drawBuffer(Minecraft.getInstance(), FILLED_THROUGH_WALLS);
    }

    private static void box(Matrix4fc m, BufferBuilder b, float x0, float y0, float z0, float x1, float y1, float z1,
                            float r, float g, float bl, float a) {
        // Front
        b.addVertex(m, x0, y0, z1).setColor(r, g, bl, a);
        b.addVertex(m, x1, y0, z1).setColor(r, g, bl, a);
        b.addVertex(m, x1, y1, z1).setColor(r, g, bl, a);
        b.addVertex(m, x0, y1, z1).setColor(r, g, bl, a);
        // Back
        b.addVertex(m, x1, y0, z0).setColor(r, g, bl, a);
        b.addVertex(m, x0, y0, z0).setColor(r, g, bl, a);
        b.addVertex(m, x0, y1, z0).setColor(r, g, bl, a);
        b.addVertex(m, x1, y1, z0).setColor(r, g, bl, a);
        // Left
        b.addVertex(m, x0, y0, z0).setColor(r, g, bl, a);
        b.addVertex(m, x0, y0, z1).setColor(r, g, bl, a);
        b.addVertex(m, x0, y1, z1).setColor(r, g, bl, a);
        b.addVertex(m, x0, y1, z0).setColor(r, g, bl, a);
        // Right
        b.addVertex(m, x1, y0, z1).setColor(r, g, bl, a);
        b.addVertex(m, x1, y0, z0).setColor(r, g, bl, a);
        b.addVertex(m, x1, y1, z0).setColor(r, g, bl, a);
        b.addVertex(m, x1, y1, z1).setColor(r, g, bl, a);
        // Top
        b.addVertex(m, x0, y1, z1).setColor(r, g, bl, a);
        b.addVertex(m, x1, y1, z1).setColor(r, g, bl, a);
        b.addVertex(m, x1, y1, z0).setColor(r, g, bl, a);
        b.addVertex(m, x0, y1, z0).setColor(r, g, bl, a);
        // Bottom
        b.addVertex(m, x0, y0, z0).setColor(r, g, bl, a);
        b.addVertex(m, x1, y0, z0).setColor(r, g, bl, a);
        b.addVertex(m, x1, y0, z1).setColor(r, g, bl, a);
        b.addVertex(m, x0, y0, z1).setColor(r, g, bl, a);
    }

    private void drawBuffer(Minecraft client, RenderPipeline pipeline) {
        MeshData built = buffer.buildOrThrow();
        MeshData.DrawState params = built.drawState();
        VertexFormat format = params.format();

        GpuBuffer vertices = upload(params, format, built);
        draw(client, pipeline, built, params, vertices, format);

        vertexBuffer.rotate();
        buffer = null;
    }

    private GpuBuffer upload(MeshData.DrawState params, VertexFormat format, MeshData built) {
        int size = params.vertexCount() * format.getVertexSize();

        if (vertexBuffer == null || vertexBuffer.size() < size) {
            if (vertexBuffer != null) vertexBuffer.close();
            vertexBuffer = new MappableRingBuffer(() -> "vibeclient esp", GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
        }

        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView view = encoder.mapBuffer(vertexBuffer.currentBuffer().slice(0, built.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(built.vertexBuffer(), view.data());
        }
        return vertexBuffer.currentBuffer();
    }

    private static void draw(Minecraft client, RenderPipeline pipeline, MeshData built, MeshData.DrawState params,
                             GpuBuffer vertices, VertexFormat format) {
        GpuBuffer indices;
        VertexFormat.IndexType indexType;

        if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
            built.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(built.indexBuffer());
            indexType = built.drawState().indexType();
        } else {
            RenderSystem.AutoStorageIndexBuffer shape = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
            indices = shape.getBuffer(params.indexCount());
            indexType = shape.type();
        }

        GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> "vibeclient esp rendering",
                client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
                client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            pass.setPipeline(pipeline);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", transforms);
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indices, indexType);
            pass.drawIndexed(0, 0, params.indexCount(), 1);
        }
        built.close();
    }

    public void close() {
        ALLOCATOR.close();
        if (vertexBuffer != null) {
            vertexBuffer.close();
            vertexBuffer = null;
        }
    }
}
