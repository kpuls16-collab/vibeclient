package com.vibeclient;

import com.vibeclient.module.XrayModule;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;

import java.util.Locale;
import java.util.StringJoiner;

/**
 * Chat commands (never sent to the server):
 *   #xray <block>   show / stop showing that block (everything else is transparent)
 *   #xray ores      keep every ore visible (run again to turn off)
 *   #xray loot      add chests, barrels, spawners, trial spawners and vaults
 *   #xray list      show what is visible
 *   #xray clear     start over (everything transparent)
 */
public final class XrayCommands {
    private XrayCommands() {}

    /** @return true if the message was an X-Ray command and should NOT be sent. */
    public static boolean handle(String message) {
        String low = message.trim().toLowerCase(Locale.ROOT);
        if (!(low.equals("#xray") || low.startsWith("#xray ") || low.startsWith("#xray_"))) return false;

        XrayModule x = VibeClient.MODULES.get(XrayModule.class);
        String arg = low.substring(5).trim();
        if (arg.startsWith("_")) arg = arg.substring(1);
        arg = arg.trim().replace(' ', '_');
        if (arg.startsWith("minecraft:")) arg = arg.substring("minecraft:".length());

        switch (arg) {
            case "" -> say("Usage: #xray <block>  |  #xray ores  |  #xray loot  |  #xray list  |  #xray clear");
            case "list" -> {
                StringJoiner j = new StringJoiner(", ");
                for (Block b : x.visible) j.add(XrayModule.nameOf(b));
                String blocks = j.length() == 0 ? "(none)" : j.toString();
                say("X-Ray shows: " + blocks + (x.showOres ? "  + all ores" : ""));
            }
            case "clear" -> {
                x.clearVisible();
                x.refresh();
                say("X-Ray cleared. Everything is transparent.");
            }
            case "ores" -> {
                x.showOres = !x.showOres;
                if (x.showOres && !x.isEnabled()) x.setEnabled(true); else x.refresh();
                say("X-Ray ores: " + (x.showOres ? "ON" : "OFF"));
            }
            case "loot" -> {
                x.addLoot();
                if (!x.isEnabled()) x.setEnabled(true); else x.refresh();
                say("X-Ray now shows chests, barrels, spawners, trial spawners and vaults.");
            }
            default -> {
                Block b = XrayModule.findBlock(arg);
                if (b == null) {
                    say("Unknown block: " + arg);
                } else if (x.visible.remove(b)) {
                    x.refresh();
                    say("X-Ray no longer shows: " + arg);
                } else {
                    x.visible.add(b);
                    if (!x.isEnabled()) x.setEnabled(true); else x.refresh();
                    say("X-Ray now shows: " + arg);
                }
            }
        }
        return true;
    }

    private static void say(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[Vibe] " + text));
    }
}
