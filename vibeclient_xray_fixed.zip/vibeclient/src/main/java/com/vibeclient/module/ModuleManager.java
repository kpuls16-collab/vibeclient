package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new MultiplayerSafetyModule()); // first, so it runs before the others
        modules.add(new AutoTotemModule());
        modules.add(new CrystalAuraModule());
        modules.add(new EspModule());
        modules.add(new SusChunksModule());
        modules.add(new FreecamModule());
        modules.add(new AnchorAuraModule());
        modules.add(new DtapAuraModule());
        modules.add(new FastXpModule());
        modules.add(new XrayModule());
        modules.add(new NametagsModule());
    }

    public List<Module> all() { return modules; }

    /** Turns off every module except the one given. */
    public void disableAllExcept(Module keep) {
        for (Module m : modules) if (m != keep && m.isEnabled()) m.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) if (type.isInstance(m)) return (T) m;
        throw new IllegalStateException("Module not registered: " + type);
    }

    public void startTick(Minecraft mc) {
        for (Module m : modules) if (m.isEnabled()) m.onStartTick(mc);
    }

    public void tick(Minecraft mc) {
        for (Module m : modules) if (m.isEnabled()) m.onTick(mc);
    }
}
