package com.vibeclient.mixin;

import com.vibeclient.module.XrayModule;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Decides whether a block face is added to the chunk mesh. While X-Ray is on, natural terrain
 * faces are dropped and everything else is always drawn.
 *
 * The method signature is the 1.21-era one; if 26.1 changed it, this mixin quietly does nothing
 * (require = 0, and the mixin config is not required), and only the ore glow works.
 * Does not affect Sodium, which has its own face culling.
 */
@Mixin(Block.class)
public abstract class BlockXrayMixin {
    @Inject(method = "shouldRenderFace", at = @At("RETURN"), cancellable = true, require = 0)
    private static void vibeclient$xray(BlockState state, BlockGetter level, BlockPos pos, Direction face,
                                        BlockPos neighborPos, CallbackInfoReturnable<Boolean> cir) {
        if (XrayModule.renderActive) {
            cir.setReturnValue(XrayModule.isVisible(state.getBlock()));
        }
    }
}
