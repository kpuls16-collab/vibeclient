Death Chat (Fabric, Minecraft 26.1.2, Java 25)

On the death screen: Left Ctrl toggles death chat. While ON, your Open Chat
key (and Open Command key) opens chat.

BUILD
1. Copy the Gradle wrapper (gradlew, gradlew.bat, gradle/ folder) from
   https://github.com/FabricMC/fabric-example-mod into this folder
   (or have Gradle installed).
2. Run:  ./gradlew build
3. The jar is in build/libs/deathchat-1.0.0.jar -> put in your mods folder
   (needs Fabric API).

If Gradle can't find the Loom version, set loom_version in gradle.properties
to the one used by the Fabric example mod for 26.1.2.
