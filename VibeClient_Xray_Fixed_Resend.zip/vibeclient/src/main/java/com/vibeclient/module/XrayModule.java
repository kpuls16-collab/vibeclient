package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * X-Ray. Two parts:
 *  1. Terrain transparency: plain natural blocks (stone, dirt, netherrack...) stop being drawn,
 *     so you see through the ground. Anything NOT on that list stays solid: every ore (including
 *     nether gold, quartz and ancient debris) and anything that looks player-made (planks,
 *     cobblestone, bricks, chests, glass...). This part hooks block face culling (BlockXrayMixin).
 *  2. Ore glow: ores are also outlined through walls, which works even if (1) can't hook in.
 *
 * "Player-placed" is a best guess: the game doesn't record who placed a block, so blocks that
 * are not natural terrain count as player-made. Stone or dirt you placed yourself will vanish too.
 */
public class XrayModule extends Module {
    /** Read by the mixin on the chunk-building threads. */
    public static volatile boolean renderActive;

    // Settings
    public boolean terrainTransparent = true;
    public boolean oreGlow = true;
    public int radius = 24;
    public int scanInterval = 20;
    public int maxHits = 2000;

    private static final Set<Block> HIDDEN = new HashSet<>();
    static {
        Block[] natural = {
                Blocks.STONE, Blocks.GRANITE, Blocks.DIORITE, Blocks.ANDESITE, Blocks.DEEPSLATE, Blocks.TUFF,
                Blocks.DIRT, Blocks.COARSE_DIRT, Blocks.ROOTED_DIRT, Blocks.GRASS_BLOCK, Blocks.PODZOL,
                Blocks.MYCELIUM, Blocks.MUD, Blocks.GRAVEL, Blocks.SAND, Blocks.RED_SAND, Blocks.SANDSTONE,
                Blocks.RED_SANDSTONE, Blocks.CLAY, Blocks.TERRACOTTA, Blocks.SNOW_BLOCK, Blocks.MOSS_BLOCK,
                Blocks.CALCITE, Blocks.SMOOTH_BASALT, Blocks.DRIPSTONE_BLOCK, Blocks.BEDROCK,
                Blocks.NETHERRACK, Blocks.BASALT, Blocks.BLACKSTONE, Blocks.SOUL_SAND, Blocks.SOUL_SOIL,
                Blocks.MAGMA_BLOCK, Blocks.END_STONE};
        for (Block b : natural) HIDDEN.add(b);
    }

    private volatile List<EspModule.Hit> found = List.of();
    private int ticks;

    public XrayModule() {
        super("X-Ray", "Visuals");
        settings.add(Setting.ofBool("See-through terrain", () -> terrainTransparent, v -> { terrainTransparent = v; updateActive(); refreshWorld(); }));
        settings.add(Setting.ofBool("Ore glow", () -> oreGlow, v -> oreGlow = v));
        settings.add(Setting.ofInt("Glow radius", () -> radius, v -> radius = v, 8, 48, 4));
    }

    public List<EspModule.Hit> getFound() { return found; }

    /**
     * True for blocks that stay drawn. Minecraft does not store whether a block was
     * player-placed, so this uses a conservative name-based classification for natural
     * world-generation blocks in addition to the explicit terrain list above.
     */
    public static boolean isVisible(Block b) {
        if (isOre(b)) return true;

        if (HIDDEN.contains(b)) return false;

        String path = BuiltInRegistries.BLOCK.getKey(b).getPath();

        // Natural tree and vegetation blocks.
        if (path.endsWith("_log") || path.endsWith("_wood")
                || path.endsWith("_leaves") || path.endsWith("_sapling")
                || path.endsWith("_propagule") || path.endsWith("_roots")
                || path.endsWith("_hanging_roots") || path.endsWith("_stem")
                || path.endsWith("_hyphae") || path.endsWith("_wart_block")
                || path.endsWith("_mushroom_block") || path.endsWith("_mushroom")
                || path.endsWith("_coral") || path.endsWith("_coral_block")
                || path.endsWith("_coral_fan") || path.endsWith("_coral_wall_fan")
                || path.endsWith("_seagrass") || path.endsWith("_kelp")
                || path.endsWith("_flower") || path.endsWith("_tulip")
                || path.endsWith("_orchid") || path.endsWith("_daisy")
                || path.endsWith("_allium") || path.endsWith("_bluet")
                || path.endsWith("_poppy") || path.endsWith("_fungus")
                || path.endsWith("_bush") || path.endsWith("_grass")
                || path.endsWith("_fern") || path.endsWith("_lichen")
                || path.endsWith("_vines") || path.equals("vine")
                || path.equals("glow_lichen") || path.equals("lily_pad")
                || path.equals("big_dripleaf") || path.equals("small_dripleaf")
                || path.equals("cactus") || path.equals("sugar_cane")
                || path.equals("dead_bush") || path.equals("azalea")
                || path.equals("flowering_azalea") || path.equals("mangrove_roots")
                || path.equals("muddy_mangrove_roots")) {
            return false;
        }

        // Naturally occurring soil, stone, sand, ice and other terrain variants.
        if (path.equals("stone") || path.equals("granite") || path.equals("diorite")
                || path.equals("andesite") || path.equals("smooth_stone") || path.equals("infested_stone")
                || path.contains("deepslate")
                || path.contains("dirt") || path.contains("grass_block")
                || path.contains("sand") || path.contains("gravel")
                || path.contains("clay") || path.contains("terracotta")
                || path.contains("ice") || path.contains("snow")
                || path.contains("basalt") || path.contains("netherrack")
                || path.contains("blackstone") || path.contains("end_stone")
                || path.contains("tuff") || path.contains("calcite")
                || path.contains("dripstone") || path.contains("moss")
                || path.contains("rooted_dirt") || path.contains("podzol")
                || path.contains("mycelium") || path.contains("soul_soil")
                || path.contains("soul_sand") || path.contains("magma")
                || path.contains("obsidian") || path.contains("bedrock")
                || path.equals("amethyst_block") || path.equals("budding_amethyst") || path.contains("sponge")
                || path.contains("sculk") || path.contains("pointed_dripstone")
                || path.contains("powder_snow") || path.contains("packed_ice")
                || path.contains("blue_ice")) {
            return false;
        }

        // Anything not recognized as natural terrain remains visible as a likely
        // player-built block (including planks, bricks, glass, chests and machines).
        return true;
    }

    public static boolean isOre(Block b) {
        String path = BuiltInRegistries.BLOCK.getKey(b).getPath();
        return path.endsWith("_ore") || path.equals("ancient_debris");
    }

    private void updateActive() {
        renderActive = isEnabled() && terrainTransparent;
    }

    /** Makes the game rebuild its chunk meshes so the change shows up. */
    private void refreshWorld() {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.level == null) return;
        try {
            mc.levelRenderer.allChanged();
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onEnable() {
        updateActive();
        refreshWorld();
        ticks = scanInterval;
    }

    @Override
    protected void onDisable() {
        updateActive();
        refreshWorld();
        found = List.of();
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !oreGlow) { found = List.of(); return; }
        if (++ticks < scanInterval) return;
        ticks = 0;

        BlockPos c = p.blockPosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        List<EspModule.Hit> out = new ArrayList<>();

        scan:
        for (int x = c.getX() - radius; x <= c.getX() + radius; x++) {
            for (int z = c.getZ() - radius; z <= c.getZ() + radius; z++) {
                for (int y = c.getY() - radius; y <= c.getY() + radius; y++) {
                    m.set(x, y, z);
                    Block b = mc.level.getBlockState(m).getBlock();
                    if (!isOre(b)) continue;
                    int rgb = java.awt.Color.HSBtoRGB((BuiltInRegistries.BLOCK.getKey(b).getPath().hashCode() & 0xFFFF) / 65535f, 0.85f, 1f);
                    out.add(new EspModule.Hit(x, y, z, ((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f));
                    if (out.size() >= maxHits) break scan;
                }
            }
        }
        found = List.copyOf(out);
    }
}
